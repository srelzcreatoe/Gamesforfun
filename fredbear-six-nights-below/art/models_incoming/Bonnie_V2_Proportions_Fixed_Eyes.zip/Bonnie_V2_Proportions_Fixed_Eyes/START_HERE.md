# Bonnie: V2 proportions with corrected eyes

## Open this project

Open `Bonnie_V2_Proportions_Fixed_Eyes.bbmodel`.
The texture and all eight animations are embedded. Select one full-body clip at a time.
This is a new filename so it will not overwrite or be confused with the earlier V2/V3 projects.

## What is restored

This project starts from the original V2 file. The head, crown, cheeks, muzzle, nose,
jaw, teeth, ears, neck, torso, limbs, hands, fingers and banjo retain their original
V2 geometry. All 46 original rig pivots and rotations are also identical to V2.
The taller V3 head and raised ear attachments are not present.

## What is kept from the eye fix

The complete eye openings are closer together, at 7.40 model units between centers
instead of the old 9.72. The pupils remain centered in their own white surfaces;
neither pupil is moved toward the nose. The eye textures are symmetric, without
an offset highlight. Both eyes point forward relative to the head.

The visible eye openings have been fitted to the original V2 head, without changing
its external proportions. Six eye-socket/rim pieces are horizontally adjusted, and
two slim socket-side trims close the former outer gaps. The other 282 original
cuboids are unchanged. Four eye alignment bones retain the corrected gaze.

The normal eye surfaces are red. Both performance clips use white eyes with purple
irises and dark centered pupils. The other six clips restore the red eyes.

## Animations

All original V2 body, head, hand and finger motion tracks are preserved exactly.
Only the four static eye-alignment tracks are additional.

- `animation.bonnie_plus.idle`: 6 seconds, loop.
- `animation.bonnie_plus.walk`: 1.6 seconds, loop.
- `animation.bonnie_plus.run`: 0.8 seconds, loop.
- `animation.bonnie_plus.pose_watch`: 1.5 seconds, holds final frame.
- `animation.bonnie_plus.pose_stage`: 1 second, holds final frame.
- `animation.bonnie_plus.pose_powered_down`: 2 seconds, holds final frame.
- `animation.bonnie_plus.perform_rhythm`: 4 seconds, loop, white/purple eyes.
- `animation.bonnie_plus.perform_solo`: 6 seconds, loop, white/purple eyes.

## Included files

- Editable `.bbmodel` with embedded texture and animations.
- Matching `.geo.json`, `.animation.json` and `.png` exports.
- `individual_animations/`: each of the eight clips separately.
- `bedrock/`: matching exports under the original resource-pack paths.
- `previews/`: actual model renders.
- `validation_report.json`: exact V2 comparison and animation checks.

Use the combined animation bank OR the separate clip files, not duplicate copies of
both. Use the new model, texture and animation exports together.
The geometry identifier remains `geometry.bonnie_plus`, and all animation identifiers
remain unchanged. This is an asset package, not a complete summonable add-on.

## Checks and limitations

294 cuboids, 50 bones and eight clips. All 282 non-eye cuboids and all original V2
bone properties match the original file exactly. Embedded and exported animation
channels match. The preview is rendered from the actual file data.

Over 1,382 sampled animation frames, all original V2 bone transforms remained
identical, the gaze axes stayed parallel, and the correct eye mode was visible.
The supplied package has not been import-tested inside the Blockbench application
or run-tested in Minecraft. Validation is not an exhaustive collision test.

Unofficial fan-character asset.

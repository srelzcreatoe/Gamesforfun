BONNIE — CLASSIC FREDDY PROPORTIONS + JUMPSCARE

Open Bonnie_Midnight_Banjo.bbmodel in Blockbench and select Animate.
The model contains its texture and all eight animations. Play one clip at a time.
Select animation.bonnie.idle for the resting pose and hidden banjo.

WHAT CHANGED
- Added animation.bonnie.jumpscare: a 2.2-second one-shot with a planted-foot
  lunge, reaching arms, grabbing fingers, two jaw snaps, and ear follow-through.
- Bonnie and the supplied Classic Freddy have exactly the same head-top height:
  52.35 model units above the soles in neutral standing geometry.
- Ears and Freddy's hat are excluded from the height match. Bonnie's ears extend
  above the shared head-height line; his overall height with ears is 63.81237.
- The body is no longer vertically compressed. The Classic Freddy head shell,
  torso, pelvis, shoulders, limb shells, and feet are used at full dimensions.
- The eye centers remain 4.16 units apart, reduced from the original 7.40 units.
- Hands remain articulated and rest with palms facing inward. All eight clips,
  including the instrument grips, are retargeted to the full-height skeleton.
- Bonnie retains his blue-purple suit, cream face and belly, red bow tie, rabbit
  ears and incisors, banjo, red eyes, and white-purple performance eyes.

FILES
Bonnie_Midnight_Banjo.bbmodel      Editable project with embedded animations.
bonnie.geo.json                   Bedrock geometry.
bonnie.animation.json             All eight Bedrock animations.
bonnie.texture.png                1024 x 1024 pixel texture atlas.
Individual_Animations/            The eight clips as individual JSON files.
bonnie.jumpscare.animation.json    Standalone jumpscare animation.
Bonnie_Jumpscare_Preview.mp4       Real-time, half-speed and side-view preview.
Bonnie_Jumpscare_Poses.png         Key poses of the new jumpscare.
Bonnie_Animation_Preview.mp4       Updated actual-model animation preview.
Bonnie_Model_Preview.png           Front, side, back and detail renders.
Bonnie_Animation_Poses.jpg          Overview of all eight clips.
Bonnie_Classic_Freddy_Comparison.png  Both models rendered at the same scale.
Source/                          Rebuild inputs, scripts and validation report.

ANIMATIONS
animation.bonnie.idle             6.0 seconds, loop.
animation.bonnie.walk             1.6 seconds, loop, in place.
animation.bonnie.run              0.9 seconds, loop, in place.
animation.bonnie.pose_wave        3.5 seconds, hold last frame.
animation.bonnie.pose_menacing    3.0 seconds, hold last frame.
animation.bonnie.perform_strum    6.0 seconds, loop.
animation.bonnie.perform_show     8.0 seconds, loop.
animation.bonnie.jumpscare        2.2 seconds, plays once.

BEDROCK
Geometry identifier: geometry.bonnie_midnight_banjo
Use the geometry under models/entity, the texture under textures/entity, and
animation JSON under animations in your resource pack. Bind these assets in your
own client entity and animation controller. This is a model and animation pack.
The two banjo performances switch to the performance eyes and reveal the prop;
all other clips hide the prop and use red eyes. These are complete pose clips.
The jumpscare uses 8 model units of forward root-bone motion (half a block).
This is visual motion; it does not move the entity position or control a player
camera. Trigger the one-shot in your controller and leave the state on completion.

VERIFICATION
The preview renders the delivered geometry, texture and exported animation keys.
Checks cover matching native/exported animation keys, bone references, loop
closure, forward finger and elbow hinges, knee direction, ground clearance,
selected body-part clearances, and the height/proportion measurements.
See Source/validation_report.json for the sampled checks and their limits.
The assets have not been tested inside Minecraft or the Blockbench application.

REBUILD
Python 3.12, Source/requirements.txt, FFmpeg, and an EGL/OpenGL-capable system.
Run from the extracted folder:
  python Source/build_bonnie.py
  python Source/animate_bonnie.py
  python Source/validate_bonnie.py
  python Source/make_preview.py stills
  python Source/make_preview.py video
  python Source/preview_jumpscare.py
The source inputs retain the original Bonnie rig and the supplied Classic Freddy
geometry needed to reproduce this revision. Only Bonnie's deliverable is updated.

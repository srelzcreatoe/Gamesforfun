SPRINGBONNIE + SPOTTY — BLOCKBENCH MODEL & ANIMATION SET

Two original reconstructions based on your supplied concept-art images.
Each character includes an editable, textured Blockbench project plus matching
Minecraft Bedrock geometry, animation JSON, and PNG texture atlas.

OPEN THE MODELS
1. Use Blockbench 5.0 or newer.
2. Open Springbonnie.bbmodel or Spotty.bbmodel with File > Open Model.
3. Textures and nine animation clips are embedded in each project.
4. Switch to Animate, choose a clip, and press Play.

CLIPS IN EACH MODEL
idle            Slow mechanical holds, head tracking and small finger motion.
walk            Deliberate weighted walking cycle, animated hands and fingers.
run             Faster chase cycle with forward upper-body drive.
pose_watch      Enter and hold an unnerving watching pose.
pose_threat     Enter and hold a reaching threat pose.
pose_stage      Enter and hold a stage presentation pose.
perform_1       First looping performance with timed robotic gestures.
perform_2       Second distinct looping performance with finger articulation.
jumpscare       Unique one-shot attack for each character, with a final hold.

Pose clips and jumpscares hold their final frame. The other clips loop. Walking and running
are authored in place so gameplay can move the entity independently.
The left and right palms face inward at rest; fingers curl toward the palms.
All costume pieces are rigid cuboids. No mesh skinning, squash or stretch.

BEDROCK EXPORTS
Each character folder includes <id>.geo.json, <id>.animation.json and
<id>.png. Animation IDs use animation.<id>.<clip>, and geometry IDs use
geometry.<id>. These are model/animation assets, not a complete .mcaddon.
An entity definition, renderer and behavior pack are still needed to spawn
or control them in a Minecraft world. No scripts are required by the models.
Authored units use 16 units per block; adjust your entity scale to taste.
A scale near 0.625 gives a roughly 3-block Springbonnie including ears and
a roughly 2.5-block Spotty.

PREVIEWS AND VERIFICATION
MP4s render the actual exported source geometry, texture atlases, and clips.
Original showcase videos show the turntable and eight original clips.
Dedicated Jumpscare_Preview videos show the added ninth clip at normal speed,
from the front, and at half speed.
They are studio rig previews rather than Minecraft gameplay recordings.
JSON structure, bone links, texture mapping bounds, animation transforms,
loop endpoints and internal/Bedrock coordinate conversion are checked.
Selected moving shell and finger pairs are sampled for joint clearance.
Blockbench and Minecraft GUI playback were not available for an in-app test.
The two requested YouTube links could not be accessed; movements are authored
from your described robotic motion requirements, not copied from those videos.

FILES
Springbonnie/ and Spotty/ contain editable models, textures and Bedrock exports.
Previews/ contains MP4s and model contact sheets.
Source/ contains reproducible model, atlas, animation, export and render code.
Validation/ contains the structural validation results.

SOURCE REBUILD
Requires Python 3, numpy and Pillow. From Source, run export_models.py.
The preview renderer also uses a C++ compiler and FFmpeg.
All source files are provided so the proportions, paint and timing remain editable.

JUMPSCARE UPDATE
Springbonnie: sudden forward ambush with an opening jaw and asymmetric claws.
Spotty: a delayed head-tilt feint followed by a two-handed reaching grab.
The model geometry, texture atlases and original eight animations are preserved.
The new clip is animation.springbonnie.jumpscare or animation.spotty.jumpscare.
Jumpscare-only JSONs can be imported into the matching existing projects.
The updated .bbmodel files and full animation JSONs already include the clip.
They hold at the end; an entity controller should transition back to another
state when appropriate. The exported root lunge is real model-space motion.
No camera commands or sound effects are bundled with these animation assets.

FREDDY ANIMATRONICS — CLASSIC FREDDY EYELID AND TEETH UPDATE

Open Classic_Freddy/classic_freddy.bbmodel directly in Blockbench. Its texture
and every animation are embedded. Use the Animate workspace to preview them.

EYE STATES

Rest: blue eyes at the original model's open eyelid level, softer brows and
the original brief idle blink. The lids no longer sit lowered at rest.
Active: black eyes with one small white pupil per eye; lids open fully.

Classic Freddy uses relaxed eyes in idle, pose_showman, perform_sing and
perform_present. Walk, run, pose_stare, chase and jumpscare use active eyes.
The separate eyes_relaxed and eyes_active clips let you preview or reuse the
eye states on their own. The eye banks move into and out of the solid skull;
all meshes remain rigid, and no body scaling is used.

Classic Freddy's existing body proportions, hands, feet, suit pixels and
original body animation tracks are preserved. The eyelids use their original geometry, hinge, resting angle and idle blink.
The upper tooth row has been removed. Eight bottom teeth are attached to the
lower jaw and follow its singing and jumpscare motion. Chase and jumpscare
clips and the active black-eye / white-pupil behavior are retained.
The included Withered Freddy model and animation files are unchanged.

FILES

Classic_Freddy/classic_freddy.bbmodel
  Updated editable project: 53 bones, 1,021 cuboids, 11 animation entries.

Classic_Freddy/classic_freddy.animation.json
  Separate Bedrock animation export containing all 11 entries.

Classic_Freddy/classic_freddy.geo.json and classic_freddy.png
  Matching Bedrock geometry and 1024 x 1024 texture atlas.

Classic_Freddy/classic_freddy.animation_controllers.json
  Eye controller and optional basic locomotion/chase/jumpscare controller.

Freddy_Animation_Preview.mp4
  Actual updated model with a full-body view and simultaneous facial close-up:
  relaxed idle and performance, activation, walking, running, chase,
  jumpscare, and return to relaxed idle.

Classic_Freddy_Eye_States.png
  Close-up comparison of the two eye appearances.

Freddy_Models_Preview.png
  Rest-pose view of both models.

CLASSIC FREDDY ANIMATION ENTRIES

idle               6.00 s    loop
walk               1.60 s    loop
run                0.80 s    loop
pose_stare         2.50 s    hold last frame
pose_showman       3.00 s    hold last frame
perform_sing       6.40 s    loop
perform_present    7.20 s    loop
chase              0.80 s    loop, reaching left hand
jumpscare          1.80 s    one shot, hold last frame
eyes_relaxed       1.00 s    eye-only loop
eyes_active        1.00 s    eye-only loop

BEDROCK INTEGRATION

The eye change is already included in the individual model animation clips.
For automatic game-state control, use the supplied eye controller after your
body controller in the client entity's scripts.animate list. The example
client bindings and render controller are in Bedrock_Integration.

The eye controller activates for movement, an acquired target, or a delayed
attack. It stays active for the complete jumpscare when used with the supplied
body controller. Existing entity targeting and attack behavior supplies these
signals; this pack contains model and animation assets, not a guard AI or a
complete spawnable add-on.

If integrating with your existing body controller, merge the animation aliases,
initialize variable.freddy_jumpscare_active to 0, and append freddy_eyes after
your body animation in scripts.animate. Set that variable to 1 while a custom
jumpscare is playing and return it to 0 on exit. The relaxed eye overlay leaves
the body's blink motion intact. The active overlay opens the lids and prevents
a relaxed blink from hiding the white pupils.

Example resource-pack destinations:
  models/entity/classic_freddy.geo.json
  textures/entity/classic_freddy.png
  animations/classic_freddy.animation.json
  animation_controllers/classic_freddy.animation_controllers.json
  entity/classic_freddy.entity.json
  render_controllers/classic_freddy.render_controllers.json

Change the example client identifier to match your existing behavior entity.
Use your existing body controller for stage-performance triggers, or the
optional included controller for basic idle, movement, chase and delayed attack.

VALIDATION

Verification/face_update_validation.json checks exact restoration of the
original lid geometry and idle blink, removal of every upper tooth, eight
teeth parented to the lower jaw, matching geometry/animation exports and
preservation of unrelated geometry and motion tracks. The model's eye states,
lower teeth in jaw motion, and encoded preview were visually checked.
The earlier complete rig validation is retained as a baseline report.
Withered Freddy's files remain byte-identical.
The supplied Bedrock integration has not been run inside Minecraft.

OPTIONAL REBUILD

The Sources folder preserves the model generation, eye patch, rendering and
validation scripts. Install Sources/requirements.txt; FFmpeg is needed for MP4.
Run from the extracted pack folder:

  python Sources/rebuild.py
  python Sources/update_eyes.py Classic_Freddy Classic_Freddy
  python Sources/build_integration.py
  python Sources/validate_rebuilt.py
  python Sources/preview_eyes.py stills
  python Sources/preview_eyes.py video

Rebuilding overwrites the extracted models. Apply the eye patch once after
generating the base models. The patch rejects an already-patched project.

Implementation references:
https://learn.microsoft.com/en-us/minecraft/creator/documents/animations/animationsoverview
https://github.com/Mojang/bedrock-samples/blob/main/documentation/Molang.html
https://github.com/Mojang/bedrock-samples/blob/main/documentation/Animations.html

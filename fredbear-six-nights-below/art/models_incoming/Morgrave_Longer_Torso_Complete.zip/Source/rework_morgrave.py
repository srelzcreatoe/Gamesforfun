"""Extend the existing Morgrave torso while preserving the rigid assemblies."""
from pathlib import Path
from copy import deepcopy
from collections import OrderedDict
import json
import numpy as np
import model_core as core

ROOT=Path(__file__).resolve().parent
core.OUT=ROOT/'build'
LENGTH_FACTOR=1.924
WAIST_Y=25.05

def descendants(bones,name):
    result={name}
    while True:
        expanded=result|{n for n,b in bones.items() if b['parent'] in result}
        if result==expanded:return result
        result=expanded

def main():
    original=json.loads((ROOT/'base_morgrave.json').read_text())
    m=core.Model('morgrave','Morgrave — Longer Torso')
    m.bones=OrderedDict(deepcopy(original['bones']))
    m.cubes=deepcopy(original['cubes'])
    m.meta=deepcopy(original['meta'])
    m.anims=deepcopy(original['anims'])
    # Keep the waist hinge fixed. Move details up with the elongated shell,
    # preserving the thickness of ribs, bowtie pieces and spine rings.
    for cube in m.cubes:
        if cube['bone']!='torso':continue
        def stretch_y(y):return y if y<=WAIST_Y else WAIST_Y+(y-WAIST_Y)*LENGTH_FACTOR
        old_center=cube['center'][1]
        old_half=cube['size'][1]/2
        for field in ['center','pivot']:
            cube[field][1]=round(stretch_y(cube[field][1]),5)
        if not cube['name'].startswith(('bow_','exposed_rib','spine_ring')):
            low=stretch_y(old_center-old_half);high=stretch_y(old_center+old_half)
            cube['size'][1]=round(high-low,5)
            cube['center'][1]=round((low+high)/2,5)
            if cube['rotation']==[0,0,0]:cube['pivot'][1]=cube['center'][1]
    # Translate each attached assembly, including its pivots, as a rigid unit.
    rises={}
    for mount in ['neck','upper_arm_l','upper_arm_r']:
        rise=round((m.bones[mount]['pivot'][1]-WAIST_Y)*(LENGTH_FACTOR-1),5)
        rises[mount]=rise
        names=descendants(m.bones,mount)
        for name in names:m.bones[name]['pivot'][1]=round(m.bones[name]['pivot'][1]+rise,5)
        for cube in m.cubes:
            if cube['bone'] in names:
                for field in ['center','pivot']:cube[field][1]=round(cube[field][1]+rise,5)
    m.meta.update(render_height=74.5,revision='Longer chest matching the final Valek length scale',
        torso_length_factor=LENGTH_FACTOR,waist_anchor_y=WAIST_Y,mount_rises=rises)
    core.make_texture(m)
    dest=core.OUT/m.key
    core.dump(dest/'morgrave.geo.json',core.export_geo(m))
    core.dump(dest/'morgrave.animation.json',core.export_animations(m))
    core.dump(dest/'morgrave.bbmodel',core.export_bbmodel(m))
    core.dump(dest/'source_model.json',{'key':m.key,'title':m.title,'bones':m.bones,'cubes':m.cubes,'meta':m.meta,'anims':m.anims})
    assert m.anims==original['anims']
    assert len(m.cubes)==len(original['cubes'])
    for old,new in zip(original['cubes'],m.cubes):
        assert old['rotation']==new['rotation']
        assert old['size'][0]==new['size'][0] and old['size'][2]==new['size'][2]
        if old['bone']!='torso' or old['name'].startswith(('bow_','exposed_rib','spine_ring')):
            assert old['size']==new['size']
    core.dump(ROOT/'proportion_checks.json',{
        'character':'morgrave','torso_vertical_scale':LENGTH_FACTOR,
        'matches_final_valek_torso_vertical_scale':True,'waist_hinge_unchanged':True,
        'torso_width_depth_unchanged':True,'other_body_part_dimensions_unchanged':True,
        'bowtie_and_rib_thickness_preserved':True,'animation_channels_preserved':True,
        'mount_rises_model_units':rises,'all_part_rotations_preserved':True})
    print('Morgrave:',len(m.cubes),'cubes,',len(m.bones),'bones, four animations; torso length factor',LENGTH_FACTOR)

if __name__=='__main__':main()

"""Structural and sampled rig checks. This is not a Minecraft runtime test."""
import json, math
from pathlib import Path
import numpy as np
from PIL import Image
from render_core import Renderer,rotation

ROOT=Path(__file__).resolve().parent

def intersects(c1,R1,e1,c2,R2,e2,tolerance=.10):
 # Full OBB SAT with small penetration tolerance for touching plates.
 axes=[R1[:,i] for i in range(3)]+[R2[:,i] for i in range(3)]
 axes += [np.cross(R1[:,i],R2[:,j]) for i in range(3) for j in range(3)]
 delta=c2-c1
 for a in axes:
  L=np.linalg.norm(a)
  if L<1e-7:continue
  a=a/L
  r1=np.sum(e1*np.abs(R1.T@a));r2=np.sum(e2*np.abs(R2.T@a))
  if abs(delta@a)>=r1+r2-tolerance:return False
 return True

def check():
 renderer=Renderer(100,100);reports=[];errors=[]
 for key,a in renderer.actors.items():
  path=ROOT/'build'/key
  bb=json.loads((path/(key+'.bbmodel')).read_text())
  geo=json.loads((path/(key+'.geo.json')).read_text())['minecraft:geometry'][0]
  exported=json.loads((path/(key+'.animation.json')).read_text())['animations']
  assert len(bb['elements'])==len(a.cubes)
  assert len(exported)==4 and len(bb['animations'])==4
  assert set(x['name'] for x in geo['bones'])==set(a.bones)
  for b in geo['bones']:
   if 'parent' in b:assert b['parent'] in a.bones
   original_bone=a.bones[b['name']]
   assert np.allclose(b['pivot'],np.array(original_bone['pivot'])*[-1,1,1])
   originals=[c for c in a.cubes if c['bone']==b['name']]
   assert len(originals)==len(b.get('cubes',[]))
   for c,ec in zip(originals,b.get('cubes',[])):
    lo=np.array(c['center'])-np.array(c['size'])/2
    hi=np.array(c['center'])+np.array(c['size'])/2
    assert np.allclose(ec['origin'],[-hi[0],lo[1],lo[2]],rtol=0,atol=5.1e-6)
    assert np.allclose(ec['size'],c['size'])
    assert np.allclose(ec.get('rotation',[0,0,0]),np.array(c['rotation'])*[-1,-1,1])
  for aname,internal in a.anims.items():
   ex=exported[f'animation.nightcast.{key}.{aname}']
   assert ex['animation_length']==internal['length']
   for bone,chs in internal['bones'].items():
    for channel,keys in chs.items():
     flips=np.array([-1,-1,1] if channel=='rotation' else [-1,1,1])
     for time,value in keys.items():assert np.allclose(ex['bones'][bone][channel][time],np.array(value)*flips)
  tex=Image.open(path/(key+'.texture.png'))
  for c in a.cubes:
   assert min(c['size'])>0
   for uv in c['uv'].values():assert min(uv)>=0 and uv[0]+uv[2]<=tex.width and uv[1]+uv[3]<=tex.height
  foot_min=1000.;foot_max=-1000.;rot_ranges={};samples=0;hits=[]
  # Torso hit volume excludes collar and shoulder attachments.
  if a.meta['kind']=='biped':
   torso_center=np.array([0,33.01,-.15]);torso_ext=np.array([5.3,8.65,3.2])
   hands=[c for c in a.cubes if c['bone'].startswith(('hand_','finger_','thumb_'))]
   jaw=[c for c in a.cubes if c['name'].startswith(('lower_chin','chin_mask'))]
  else:hands=[];jaw=[]
  for name,anim in a.anims.items():
   T=anim['length']
   if anim['loop']:
    for chs in anim['bones'].values():
     for keys in chs.values():assert np.max(np.abs(np.array(list(keys.values())[0])-list(keys.values())[-1]))<1e-4
   for bn,chs in anim['bones'].items():
    for ch,keys in chs.items():
     vv=np.array(list(keys.values()));assert np.isfinite(vv).all();assert ch in ('rotation','position')
     if ch=='rotation':
      low,hi=rot_ranges.get(bn,(1000,-1000));rot_ranges[bn]=(min(low,float(vv[:,0].min())),max(hi,float(vv[:,0].max())))
      if bn.startswith('forearm_'):assert vv[:,0].min()>=0 and vv[:,0].max()<=100,(key,name,bn)
      if bn.startswith('shin_'):assert vv[:,0].max()<=0 and vv[:,0].min()>=-110,(key,name,bn)
      if bn=='jaw':assert vv[:,0].max()<=0 and vv[:,0].min()>=-65
   for t in np.linspace(0,T,round(T*20)+1):
    mats,by=a.matrices(name,float(t));samples+=1
    assert np.max(np.abs(np.linalg.det(mats[:,:3,:3])-1))<1e-8
    for n in a.names:
     if n.startswith('foot_') or '_paw_' in n:
      b=a.bones[n];sole=np.array(b['pivot'])+[0,-2.8,0]
      yy=float((by[n]@np.r_[sole,1])[1]);foot_min=min(foot_min,yy);foot_max=max(foot_max,yy)
      if yy<-.015:errors.append(f'{key} {name} {t:.3f} sole below floor {yy:.3f}')
    # Inspect the core torso versus every hand plate and jaw chin at 10 Hz.
    if hands and round(t*20)%2==0:
     tm=by['torso'];tc=tm[:3,:3]@torso_center+tm[:3,3]
     for c in hands+jaw:
      mm=by[c['bone']];rr=rotation(c['rotation']);pv=np.array(c['pivot']);cn=np.array(c['center'])
      center=mm[:3,:3]@(rr@(cn-pv)+pv)+mm[:3,3];rot=mm[:3,:3]@rr
      if intersects(center,rot,np.array(c['size'])/2,tc,tm[:3,:3],torso_ext,.20):
       hits.append({'animation':name,'time':round(float(t),3),'bone':c['bone'],'cube':c['name']})
  if hits:errors.append(f'{key}: {len(hits)} sampled hand/jaw versus torso intersections')
  reports.append({'character':a.title,'cubes':len(a.cubes),'bones':len(a.bones),'animations':4,
    'texture':f'{tex.width}x{tex.height}','sampled_poses':samples,'sole_min_model_units':round(foot_min,5),
    'sole_max_model_units':round(foot_max,5),'all_transforms_rigid':True,'targeted_intersections':hits[:20],
    'elbow_x_bounds':{k:v for k,v in rot_ranges.items() if k.startswith('forearm')},
    'knee_x_bounds':{k:v for k,v in rot_ranges.items() if k.startswith('shin')}})
 report={'method':'Static export validation and actual-rig sampling at 20 Hz; targeted OBB hand/jaw vs torso checks at 10 Hz.',
  'runtime_tested_in_minecraft':False,'errors':errors,'models':reports}
 (ROOT/'validation_report.json').write_text(json.dumps(report,indent=2))
 print(json.dumps(report,indent=2))
 return report

if __name__=='__main__':check()

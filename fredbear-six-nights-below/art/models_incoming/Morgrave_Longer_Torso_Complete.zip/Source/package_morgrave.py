"""Create a standalone Morgrave add-on, alongside the existing Valek pack."""
from pathlib import Path
import json,shutil,uuid,zipfile
from PIL import Image,ImageDraw,ImageFont

ROOT=Path(__file__).resolve().parent;OUT=ROOT.parent/'output'/'morgrave'
BUILD=ROOT/'build'/'morgrave';PACK=ROOT/'pack';RP=PACK/'Morgrave_Resources';BP=PACK/'Morgrave_Behaviors'
TEMPLATES=ROOT/'templates'

def uid(name):return str(uuid.uuid5(uuid.NAMESPACE_URL,'nightcast/morgrave/long-torso/v1/'+name))
def read(p):return json.loads(p.read_text())
def write(p,data):p.parent.mkdir(parents=True,exist_ok=True);p.write_text(json.dumps(data,indent=2))
def txt(p,s):p.parent.mkdir(parents=True,exist_ok=True);p.write_text(s,encoding='utf-8')
def copy(a,b):b.parent.mkdir(parents=True,exist_ok=True);shutil.copyfile(a,b)

README='''MORGRAVE — LONGER TORSO / MINECRAFT BEDROCK

The original Morgrave model now has a substantially longer chest and exposed
spine, using the same 1.924 chest length factor as the final Valek revision.
The waist hinge stays fixed. The shoulders move up 5.9598 model units, and the
neck and head assembly move up 7.3458 units. Head, ears, hands, limbs, bowtie and
rib thickness keep their previous dimensions. The original colors are retained.

Includes four rigid animations: idle, walk, perform and jumpscare. All original
rotation and position channels are retained, with the joints relocated to the
new body proportions. This is a Morgrave model update, not a new gameplay system.

OPEN IN BLOCKBENCH
Open Models/Morgrave_Longer_Torso.bbmodel. Its texture and four animations are
embedded. The separate Bedrock geometry, animation JSON and texture PNG are
also in Models/. Select Animate to inspect or edit the four clips.

BEDROCK INSTALLATION
Open Morgrave_Longer_Torso.mcaddon, then activate its resource and behavior
packs in your world. Find the Morgrave spawn egg in Creative mode.
Use an open area with at least five blocks of headroom.
The standalone pack has its own pack identifiers so it can be used with Valek.
If the original five-character Nightcast pack is also active, place Morgrave's
resource pack above it so the new geometry takes priority.

CONTROLS
Normal interact/use cycles: idle -> walk -> perform -> idle.
Crouch/sneak and interact/use plays jumpscare, then returns to idle.
Walking enables slow wandering; idle plays when the entity stops moving.
Optional commands (when commands are enabled):
/function morgrave/spawn
/function morgrave/idle
/function morgrave/walk
/function morgrave/perform
/function morgrave/jumpscare
The entity identifier is nightcast:morgrave.

VERIFICATION
The images and MP4 are rendered from the supplied model and animation data.
Checks cover rigid transforms, export coordinates, all four clips, loop closure,
feet, elbow/knee/jaw ranges and sampled hand/jaw clearance against the torso.
Minecraft itself was not available for runtime testing. No audio, attacks,
natural spawning or stalking AI is added. Minimum engine version: 1.21.0.

SOURCE
Source/ includes the model builder, renderer, validator and packaging templates.
Python dependencies: numpy, Pillow, moderngl==5.12.0. Video needs ffmpeg.
Run rework_morgrave.py, validate_core.py, preview_morgrave.py,
preview_morgrave.py --video, then package_morgrave.py.
The original Morgrave data used for the edit is Source/base_morgrave.json.
'''

def build_pack():
    for dest,role,kind in [(RP,'Resources','resources'),(BP,'Showcase','data')]:
        man={'format_version':2,'header':{'name':'Morgrave — Longer Torso '+role,
            'description':'Morgrave with an extended torso and four rigid animations.',
            'uuid':uid(role),'version':[1,0,0],'min_engine_version':[1,21,0]},
            'modules':[{'type':kind,'uuid':uid(role+' module'),'version':[1,0,0]}],
            'metadata':{'authors':['Nightcast']}}
        if kind=='data':man['dependencies']=[{'uuid':uid('Resources'),'version':[1,0,0]}]
        write(dest/'manifest.json',man)
    copy(BUILD/'morgrave.geo.json',RP/'models/entity/morgrave.geo.json')
    copy(BUILD/'morgrave.animation.json',RP/'animations/morgrave.animation.json')
    copy(BUILD/'morgrave.texture.png',RP/'textures/entity/nightcast/morgrave.png')
    client=read(TEMPLATES/'morgrave.entity.json')
    client['minecraft:client_entity']['description']['render_controllers']=['controller.render.nightcast.morgrave']
    write(RP/'entity/morgrave.entity.json',client)
    rc=read(TEMPLATES/'render_controllers.json')
    rc['render_controllers']={'controller.render.nightcast.morgrave':rc['render_controllers']['controller.render.nightcast']}
    write(RP/'render_controllers/morgrave.render_controllers.json',rc)
    copy(TEMPLATES/'animation_controllers.json',RP/'animation_controllers/morgrave.animation_controllers.json')
    entity=read(TEMPLATES/'morgrave.behavior.json')
    entity['minecraft:entity']['components']['minecraft:collision_box']['height']=4.45
    write(BP/'entities/morgrave.json',entity)
    txt(RP/'texts/en_US.lang','''entity.nightcast:morgrave.name=Morgrave
item.spawn_egg.entity.nightcast:morgrave.name=Spawn Morgrave
action.interact.nightcast_walk=Start walking
action.interact.nightcast_perform=Perform
action.interact.nightcast_idle=Return to idle
action.interact.nightcast_jumpscare=Jumpscare
''')
    write(RP/'texts/languages.json',['en_US'])
    for clip in ['idle','walk','perform','jumpscare']:
        txt(BP/'functions/morgrave'/(clip+'.mcfunction'),f'event entity @e[type=nightcast:morgrave] nightcast:{clip}\n')
    txt(BP/'functions/morgrave/spawn.mcfunction','summon nightcast:morgrave ~ ~ ~3\n')
    im=Image.open(OUT/'Morgrave_Longer_Torso_Model.png').convert('RGB').resize((256,326))
    icon=Image.new('RGB',(256,256));icon.paste(im,(0,-22));draw=ImageDraw.Draw(icon)
    draw.rectangle((0,215,256,256),fill=(32,24,25))
    font=ImageFont.truetype('/usr/share/fonts/truetype/dejavu/DejaVuSans-Bold.ttf',22)
    draw.text((58,222),'MORGRAVE',font=font,fill=(239,225,204))
    for dest in [RP,BP]:icon.save(dest/'pack_icon.png')

def verify_pack():
    assert len(list((RP/'entity').glob('*.json')))==1
    assert len(list((BP/'entities').glob('*.json')))==1
    for p in PACK.rglob('*.json'):read(p)
    client=read(RP/'entity/morgrave.entity.json')['minecraft:client_entity']['description']
    geo=read(RP/'models/entity/morgrave.geo.json')['minecraft:geometry'][0]
    assert client['geometry']['default']==geo['description']['identifier']
    clips=read(RP/'animations/morgrave.animation.json')['animations']
    assert len(clips)==4
    for name in ['idle','walk','perform','jumpscare']:assert client['animations'][name] in clips
    assert not read(ROOT/'validation_report.json')['errors']

def package():
    OUT.mkdir(parents=True,exist_ok=True);build_pack();verify_pack()
    copy(BUILD/'morgrave.bbmodel',OUT/'Morgrave_Longer_Torso.bbmodel')
    txt(OUT/'Morgrave_Read_Me.txt',README)
    addon=OUT/'Morgrave_Longer_Torso.mcaddon'
    with zipfile.ZipFile(addon,'w',zipfile.ZIP_DEFLATED) as z:
        for p in sorted(PACK.rglob('*')):
            if p.is_file():z.write(p,p.relative_to(PACK))
    bundle=OUT/'Morgrave_Longer_Torso_Complete.zip'
    with zipfile.ZipFile(bundle,'w',zipfile.ZIP_DEFLATED) as z:
        z.writestr('START_HERE.txt',README)
        z.write(OUT/'Morgrave_Longer_Torso.bbmodel','Models/Morgrave_Longer_Torso.bbmodel')
        for suffix in ['geo.json','animation.json','texture.png']:
            p=BUILD/('morgrave.'+suffix);z.write(p,'Models/'+p.name)
        z.write(addon,addon.name)
        for name in ['Morgrave_Longer_Torso_Model.png','Morgrave_Longer_Torso_Poses.jpg','Morgrave_Longer_Torso_Preview.mp4']:
            z.write(OUT/name,'Previews/'+name)
        for name in ['rework_morgrave.py','model_core.py','render_core.py','preview_morgrave.py','validate_core.py','package_morgrave.py','base_morgrave.json']:
            z.write(ROOT/name,'Source/'+name)
        for p in TEMPLATES.glob('*.json'):z.write(p,'Source/templates/'+p.name)
        for name in ['validation_report.json','proportion_checks.json']:z.write(ROOT/name,'Validation/'+name)
    for p in [addon,bundle]:
        with zipfile.ZipFile(p) as z:assert z.testzip() is None
        print(p.name,p.stat().st_size)

if __name__=='__main__':package()

"""Baked rigid-joint motion with planar leg IK and deliberately held servo poses."""
import math
import numpy as np

def smooth(x):
 x=max(0,min(1,x));return x*x*(3-2*x)

def curve(t,keys):
 if t<=keys[0][0]:return np.array(keys[0][1],float)
 for (a,x),(b,y) in zip(keys,keys[1:]):
  if t<=b:
   u=smooth((t-a)/(b-a));return np.array(x,float)*(1-u)+np.array(y,float)*u
 return np.array(keys[-1][1],float)

def scalar(t,keys):return float(curve(t,[(k,[v]) for k,v in keys])[0])

def leg_ik(dy,dz,l1,l2,bend=-1):
 d=min(math.hypot(dy,dz),l1+l2-.015)
 d=max(d,abs(l1-l2)+.05)
 theta=math.atan2(-dz,-dy)
 a=math.acos(max(-1,min(1,(l1*l1+d*d-l2*l2)/(2*l1*d))))
 flex=math.pi-math.acos(max(-1,min(1,(l1*l1+l2*l2-d*d)/(2*l1*l2))))
 upper=theta-bend*a;lower=bend*flex
 return [math.degrees(upper),math.degrees(lower),math.degrees(-upper-lower)]

def stride(phase,reach,lift,stance=.60):
 p=phase%1
 if p<stance:return -reach+2*reach*p/stance,0.0
 f=(p-stance)/(1-stance)
 return reach-2*reach*smooth(f),lift*math.sin(math.pi*f)**1.4

def base_pose(m,t):
 q={n:[0.,0.,0.] for n in m.bones}
 pos=[0.,-.85,0.]
 if m.meta['kind']=='biped':
  q['torso']=[-5,0,0]
  q['head']=[3,0,-3 if m.key=='valek' else 0]
  q['jaw']=[-18,0,0]
  for s,side in [(1,'l'),(-1,'r')]:
   q['upper_arm_'+side]=[-3,0,s*7]
   q['forearm_'+side]=[10,0,0]
   q['hand_'+side]=[-4,0,s*2]
   q['thumb_'+side]=[14,0,-s*5]
   q['thumb_'+side+'_tip']=[20,0,0]
   for i in range(4):
    q[f'finger_{side}_{i+1}']=[10+i*1.4,0,s*(i-1.5)*1.5]
    q[f'finger_{side}_{i+1}_tip']=[18+i,0,0]
  if m.key=='valek_golden':q['torso']=[-9,0,2];q['head']=[-6,-5,7]
  if m.key=='morgrave':q['head']=[1,0,2];q['ear_l']=[0,0,5];q['ear_r']=[-5,0,-6]
  if m.key=='sullen':q['head']=[0,0,-10];q['torso']=[-3,0,2]
 else:
  pos[1]=-2.2
  q['torso']=[-3,0,0];q['head']=[5,0,-2];q['jaw']=[-18,0,0]
  for s,side in [(1,'l'),(-1,'r')]:
   q['ear_'+side]=[3,0,s*6]
   for pref in ['front','rear']:
    for i in range(4):
     q[f'{pref}_finger_{side}_{i+1}']=[0,0,0]
     q[f'{pref}_finger_{side}_{i+1}_tip']=[0,0,0]
 return q,pos

def idle(m,t,T):
 q,p=base_pose(m,t);u=t/T
 # Small deliberate head search, long holds, then a short stop at the opposite angle.
 h=scalar(u,[(0,0),(.16,0),(.24,1),(.43,1),(.48,.7),(.68,-.8),(.82,-.8),(1,0)])
 q['head'][1]+=h*(8 if m.key!='sullen' else 12)
 q['head'][2]+=h*(4 if m.key!='sullen' else -7)
 q['jaw'][0]-=scalar(u,[(0,0),(.34,0),(.37,3),(.40,3),(.43,0),(1,0)])
 if m.meta['kind']=='biped':
  for side in ['l','r']:
   offset=0 if side=='l' else .35
   servo=max(0,math.sin((u+offset)*math.tau))**8
   for i in range(4):
    q[f'finger_{side}_{i+1}'][0]+=servo*(4+i*1.3)
    q[f'finger_{side}_{i+1}_tip'][0]+=servo*4
  if m.key=='morgrave':q['ear_tip_l']=[2*h,0,3*h];q['ear_tip_r']=[-2*h,0,-2*h]
  if m.key=='sullen':
   q['hat_tip_l']=[0,0,2*h];q['hat_tip_r']=[0,0,-2*h]
 else:
  q['tail']=[0,h*5,0]
  q['ear_l'][0]+=h*5;q['ear_r'][0]-=h*3
 return q,p,{}

def walking(m,t,T):
 q,p=base_pose(m,t);phase=t/T
 foot={}
 if m.meta['kind']=='biped':
  reach={'valek':3.45,'valek_golden':2.65,'morgrave':3.55,'sullen':3.15}[m.key]
  lift={'valek':1.65,'valek_golden':1.15,'morgrave':2.0,'sullen':2.2}[m.key]
  p[1]=-.93+.10*math.cos(phase*math.tau*2)
  q['torso'][1]=2.5*math.sin(phase*math.tau)
  q['head'][1]=-q['torso'][1]*.65
  q['head'][2]+=1.3*math.cos(phase*math.tau)
  for s,side,off in [(1,'l',0),(-1,'r',.5)]:
   ph=(phase+off)%1
   z,y=stride(ph,reach,lift)
   foot[side]=(z,y)
   # Arm counter-swing has restrained elbow flex, never a hyperextended elbow.
   q['upper_arm_'+side]=[-3-12*math.cos(ph*math.tau),s*1.5,s*8]
   q['forearm_'+side]=[12+5*max(0,math.cos(ph*math.tau)),0,0]
   q['hand_'+side]=[-5,0,s*2]
   for i in range(4):q[f'finger_{side}_{i+1}'][0]+=3*math.sin(ph*math.tau)**2
  if m.key=='sullen':
   q['upper_arm_l'][2]=14;q['upper_arm_r'][2]=-14
   q['head'][2]=-13+2*math.cos(phase*math.tau)
  if m.key=='morgrave':
   q['ear_tip_l'][0]=2*math.sin(phase*math.tau-.7)
   q['ear_tip_r'][0]=2.5*math.sin(phase*math.tau-1.0)
 else:
  p[1]=-2.2+.12*math.cos(phase*math.tau*2)
  q['torso']=[-3,1.5*math.sin(phase*math.tau),.7*math.sin(phase*math.tau)]
  q['head']=[6,-2*math.sin(phase*math.tau),-2]
  q['tail']=[0,5*math.sin(phase*math.tau),0]
  # Deliberate four-beat crawl; three paws spend most of the time in stance.
  for pref,side,off in [('front','l',0),('rear','r',.25),('front','r',.5),('rear','l',.75)]:
   z,y=stride((phase+off)%1,2.4 if pref=='front' else 2.1,1.25,.76)
   foot[f'{pref}_{side}']=(z-(4.0 if pref=='front' else 1.0),y)
 return q,p,foot

def perform(m,t,T):
 q,p=base_pose(m,t);u=t/T
 lift=scalar(u,[(0,0),(.08,0),(.20,1),(.32,1),(.44,.55),(.55,.55),(.68,1),(.81,1),(.96,0),(1,0)])
 turn=scalar(u,[(0,0),(.12,0),(.25,1),(.42,1),(.55,-.6),(.77,-.6),(.95,0),(1,0)])
 jaw=scalar(u,[(0,0),(.24,0),(.27,1),(.30,.2),(.35,.2),(.38,.8),(.43,0),(.60,0),(.64,.9),(.68,0),(.72,.7),(.76,0),(1,0)])
 if m.key=='valek':
  q['torso']=[-5,turn*8,0]
  q['head']=[3+lift*5,-turn*12,-3+turn*5]
  q['upper_arm_r']=[-3+lift*46,0,-7-lift*22]
  q['forearm_r']=[10+lift*44,0,0]
  q['hand_r']=[-4-lift*12,0,-2-lift*8]
  q['upper_arm_l']=[-3+lift*15,0,7+lift*13]
  q['forearm_l']=[10+lift*17,0,0]
  q['jaw'][0]=-18-jaw*16
 elif m.key=='valek_golden':
  q['torso']=[-9-lift*3,turn*3,2+turn*3]
  q['head']=[-6+lift*17,-5-turn*14,7-turn*9]
  for s,side in [(1,'l'),(-1,'r')]:
   q['upper_arm_'+side]=[-3+lift*(25 if s>0 else 39),0,s*(7+lift*12)]
   q['forearm_'+side]=[10+lift*(44 if s>0 else 26),0,0]
   q['hand_'+side]=[-4-lift*9,0,s*4]
  q['jaw'][0]=-18-jaw*22
 elif m.key=='morgrave':
  q['torso']=[-5+2*lift,turn*5,0]
  q['head']=[1+lift*6,-turn*10,2+turn*4]
  for s,side in [(1,'l'),(-1,'r')]:
   beat=scalar(u,[(0,0),(.12,0),(.22,1 if s>0 else .7),(.29,1 if s>0 else .7),(.36,.58 if s>0 else 1),(.43,.58 if s>0 else 1),(.51,1 if s>0 else .52),(.57,1 if s>0 else .52),(.65,.45 if s>0 else 1),(.73,.45 if s>0 else 1),(.90,0),(1,0)])
   q['upper_arm_'+side]=[-3+beat*61,0,s*(7+beat*33)]
   q['forearm_'+side]=[10+beat*21,0,0]
   q['hand_'+side]=[-4-beat*12,0,s*3]
  q['ear_tip_l']=[3*lift,0,3*turn];q['ear_tip_r']=[-3*lift,0,-3*turn]
  q['jaw'][0]=-18-jaw*17
 elif m.key=='sullen':
  bow=scalar(u,[(0,0),(.14,0),(.33,1),(.54,1),(.68,.25),(.8,.25),(.98,0),(1,0)])
  q['torso']=[-3-bow*12,turn*7,2]
  q['head']=[0,-turn*16,-10+turn*18]
  for s,side in [(1,'l'),(-1,'r')]:
   q['upper_arm_'+side]=[-3+lift*35,0,s*(7+lift*51)]
   q['forearm_'+side]=[10+lift*44,0,0]
   q['hand_'+side]=[-4-lift*10,0,s*lift*9]
  q['hat_tip_l']=[bow*2,0,turn*3];q['hat_tip_r']=[bow*2,0,-turn*3]
  q['bell_l']=[0,turn*5,0];q['bell_r']=[0,-turn*5,0]
  q['jaw'][0]=-18-jaw*20
 else:
  q['torso']=[-3-lift*5,turn*5,0]
  q['head']=[5+lift*13,-turn*18,-2+turn*4]
  q['jaw'][0]=-18-jaw*27
  q['ear_l']=[3-lift*13,0,6+lift*8]
  q['ear_r']=[3-lift*10,0,-6-lift*8]
  q['tail']=[lift*4,turn*9,0]
  p[1]=-2.2-lift*.35
 if m.meta['kind']=='biped':
  for s,side in [(1,'l'),(-1,'r')]:
   for i in range(4):
    q[f'finger_{side}_{i+1}'][0]=10+i*1.4+lift*(3+i*1.5)
    q[f'finger_{side}_{i+1}_tip'][0]=18+i+lift*8
 return q,p,{}

def jumpscare(m,t,T):
 q,p=base_pose(m,t);u=t/T
 # Held anticipation, short striking movement, deliberate recovery to neutral.
 attack=scalar(u,[(0,0),(.15,0),(.24,-.12),(.29,-.12),(.36,1),(.46,1),(.51,.91),(.56,1),(.69,1),(.95,0),(1,0)])
 opening=scalar(u,[(0,0),(.25,0),(.34,1),(.72,1),(.91,0),(1,0)])
 a=max(0,attack)
 if m.meta['kind']=='biped':
  p[1]=-.85-a*.72
  if m.key=='valek':
   q['torso']=[-5-attack*16,0,0];q['head']=[3+attack*8,0,-3-attack*4]
  elif m.key=='valek_golden':
   q['torso']=[-9-attack*11,0,2-attack*2];q['head']=[-6+attack*22,attack*7,7-attack*17]
  elif m.key=='morgrave':
   q['torso']=[-5-attack*18,0,0];q['head']=[1+attack*10,0,2+attack*3]
   q['ear_l']=[-a*12,0,5+a*12];q['ear_r']=[-5-a*10,0,-6-a*12]
   q['ear_tip_l']=[-a*9,0,0];q['ear_tip_r']=[-a*6,0,0]
  else:
   q['torso']=[-3-attack*18,attack*4,2];q['head']=[attack*12,-attack*9,-10+attack*29]
   q['hat_tip_l']=[a*5,0,a*4];q['hat_tip_r']=[a*5,0,-a*4]
  for s,side in [(1,'l'),(-1,'r')]:
   reach=81 if m.key!='sullen' else (72 if s>0 else 81)
   q['upper_arm_'+side]=[-3+attack*reach,0,s*(7+a*(22 if m.key!='sullen' else 34))]
   q['forearm_'+side]=[10+a*13,0,0]
   q['hand_'+side]=[-4-a*12,0,s*(2+a*4)]
   q['thumb_'+side]=[14+a*8,0,-s*(5+a*9)]
   for i in range(4):
    q[f'finger_{side}_{i+1}']=[10+i*1.4+a*(9+i),0,s*(i-1.5)*(1.5+a*4)]
    q[f'finger_{side}_{i+1}_tip']=[18+i+a*17,0,0]
  q['jaw'][0]=-18-opening*(30 if m.key!='sullen' else 29)
 else:
  # A low, short pounce; paws move with the root and land before recovery.
  hop=scalar(u,[(0,0),(.25,0),(.35,1.6),(.43,1.1),(.49,0),(1,0)])
  p[1]=-2.2+hop;p[2]=-a*4.1
  q['torso']=[-3-attack*7,0,0];q['head']=[5+attack*16,0,-2+a*4]
  q['jaw'][0]=-18-opening*36
  q['ear_l']=[3-a*20,0,6+a*7];q['ear_r']=[3-a*20,0,-6-a*7]
  q['tail']=[a*9,0,0]
 return q,p,{}

def solve_feet(m,q,p,targets,name,t,T):
 if m.meta['kind']=='biped':
  for side in ['l','r']:
   z,lift=targets.get(side,(0,0))
   a,b,c=leg_ik(2.8+lift-(21+p[1]),z,9.6,8.6,-1)
   q['thigh_'+side]=[a,0,0];q['shin_'+side]=[b,0,0];q['foot_'+side]=[c,0,0]
 else:
  for pref in ['front','rear']:
   height=22.8 if pref=='front' else 17.6
   l1=10.1 if pref=='front' else 7.6;l2=9.9 if pref=='front' else 7.2
   for side in ['l','r']:
    z,lift=targets.get(pref+'_'+side,(-4.0 if pref=='front' else -1.0,0))
    # During pounce the baked pose is kept flexed as the whole body lifts.
    py=min(p[1],-.2) if name=='jumpscare' else p[1]
    a,b,c=leg_ik(2.8+lift-(height+py),z,l1,l2,1 if pref=='front' else -1)
    q[pref+'_upper_'+side]=[a,0,0];q[pref+'_lower_'+side]=[b,0,0];q[pref+'_paw_'+side]=[c,0,0]

def animate(m):
 specs={'idle':(8.0 if m.key=='valek_golden' else 6.0,True,idle),
 'walk':({'valek':1.65,'valek_golden':2.0,'morgrave':1.7,'sullen':1.8,'dredge':2.3}[m.key],True,walking),
 'perform':(6.4,True,perform),'jumpscare':(2.2,False,jumpscare)}
 for name,(T,loop,fn) in specs.items():
  steps=round(T*40);bones={bn:{'rotation':{}} for bn in m.bones}
  bones['root']['position']={}
  for i in range(steps+1):
   t=round(T*i/steps,5)
   tt=0 if i==steps and loop else t
   q,p,feet=fn(m,tt,T);solve_feet(m,q,p,feet,name,tt,T)
   ts=f'{t:.5f}'.rstrip('0').rstrip('.') or '0'
   for bn,v in q.items():bones[bn]['rotation'][ts]=[round(float(x),4) for x in v]
   bones['root']['position'][ts]=[round(float(x),4) for x in p]
  # Remove redundant linear keys without changing the sampled pose.
  for bn,channels in bones.items():
   for ch,keys in channels.items():
    seq=list(keys.items());keep=[seq[0]]
    for j in range(1,len(seq)-1):
     a,av=keep[-1];b,bv=seq[j];c,cv=seq[j+1]
     f=(float(b)-float(a))/(float(c)-float(a))
     expected=np.array(av)*(1-f)+np.array(cv)*f
     if np.max(np.abs(expected-np.array(bv)))>.002:keep.append(seq[j])
    keep.append(seq[-1]);channels[ch]=dict(keep)
  m.anims[name]={'length':T,'loop':loop,'bones':bones}

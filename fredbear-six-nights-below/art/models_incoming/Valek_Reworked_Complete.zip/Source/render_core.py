"""Deterministic OpenGL preview of the actual exported rigid rig and pixel atlas."""
import os, json, math, argparse, subprocess
from pathlib import Path
import numpy as np
import moderngl
from PIL import Image,ImageDraw,ImageFont

ROOT=Path(__file__).resolve().parent
BUILD=ROOT/'build';RENDERS=ROOT/'renders';RENDERS.mkdir(exist_ok=True)

def rotation(v):
 x,y,z=np.radians(v);a,b,c=np.cos([x,y,z]);d,e,f=np.sin([x,y,z])
 rx=np.array([[1,0,0],[0,a,-d],[0,d,a]])
 ry=np.array([[b,0,e],[0,1,0],[-e,0,b]])
 rz=np.array([[c,-f,0],[f,c,0],[0,0,1]])
 return rz@ry@rx

def transform(rot,pivot,offset=(0,0,0)):
 mat=np.eye(4);mat[:3,:3]=rotation(rot);p=np.array(pivot)
 mat[:3,3]=p-mat[:3,:3]@p+offset
 return mat

def norm(v):return v/np.linalg.norm(v)
def look(eye,target,up=np.array([0.,1.,0.])):
 e=np.array(eye);t=np.array(target);f=norm(t-e);s=norm(np.cross(f,up));u=np.cross(s,f)
 m=np.eye(4);m[0,:3]=s;m[1,:3]=u;m[2,:3]=-f;m[:3,3]=-m[:3,:3]@e
 return m
def persp(fov,asp,near,far):
 f=1/math.tan(math.radians(fov)/2);m=np.zeros((4,4))
 m[0,0]=f/asp;m[1,1]=f;m[2,2]=(far+near)/(near-far);m[2,3]=2*far*near/(near-far);m[3,2]=-1
 return m
def ortho(l,r,b,t,n,f):
 m=np.eye(4);m[0,0]=2/(r-l);m[1,1]=2/(t-b);m[2,2]=-2/(f-n)
 m[0,3]=-(r+l)/(r-l);m[1,3]=-(t+b)/(t-b);m[2,3]=-(f+n)/(f-n)
 return m
def sample(keys,t):
 ts=np.array([float(k) for k in keys]);vs=np.array(list(keys.values()))
 i=np.searchsorted(ts,t,side='right')
 if i==0:return vs[0]
 if i>=len(ts):return vs[-1]
 u=(t-ts[i-1])/(ts[i]-ts[i-1]);return vs[i-1]*(1-u)+vs[i]*u

class Actor:
 def __init__(self,path,ctx,prog,shadow_prog):
  self.data=json.loads(Path(path).read_text());self.key=self.data['key'];self.title=self.data['title']
  self.bones=self.data['bones'];self.names=list(self.bones);self.index={n:i for i,n in enumerate(self.names)}
  self.cubes=self.data['cubes'];self.anims=self.data['anims'];self.meta=self.data['meta']
  atlas=Image.open(Path(path).parent/(self.key+'.texture.png')).convert('RGBA')
  self.texture=ctx.texture(atlas.size,4,atlas.tobytes());self.texture.filter=(moderngl.NEAREST,moderngl.NEAREST)
  self.texture.repeat_x=False;self.texture.repeat_y=False
  verts=[]
  # Vertices are wound outwards. UV first row is the top of the texture image.
  faces={
   'north':([[-1,-1,-1],[1,-1,-1],[1,1,-1],[-1,1,-1]],[0,0,-1]),
   'south':([[1,-1,1],[-1,-1,1],[-1,1,1],[1,1,1]],[0,0,1]),
   'east':([[1,-1,-1],[1,-1,1],[1,1,1],[1,1,-1]],[1,0,0]),
   'west':([[-1,-1,1],[-1,-1,-1],[-1,1,-1],[-1,1,1]],[-1,0,0]),
   'up':([[-1,1,-1],[1,1,-1],[1,1,1],[-1,1,1]],[0,1,0]),
   'down':([[-1,-1,1],[1,-1,1],[1,-1,-1],[-1,-1,-1]],[0,-1,0])}
  self.cube_rest=[]
  for c in self.cubes:
   r=rotation(c['rotation']);p=np.array(c['pivot']);cen=np.array(c['center']);sz=np.array(c['size'])
   verts8=np.array([[sx,sy,szz] for sx in [-1,1] for sy in [-1,1] for szz in [-1,1]])*sz/2+cen
   self.cube_rest.append((verts8-p)@r.T+p)
   for f,(quad,no) in faces.items():
    arr=np.array(quad)*sz/2+cen;arr=(arr-p)@r.T+p
    no=r@no
    u,v,w,h=c['uv'][f];uvs=np.array([[u,v+h],[u+w,v+h],[u+w,v],[u,v]],float)/atlas.width
    for ii in [0,1,2,0,2,3]:
     verts.append([*arr[ii],*no,*uvs[ii],float(self.index[c['bone']]),1.0 if c['mat']=='eye' else 0.0])
  a=np.array(verts,dtype='f4');self.vbo=ctx.buffer(a.tobytes())
  self.vao=ctx.vertex_array(prog,[(self.vbo,'3f 3f 2f 1f 1f','in_pos','in_normal','in_uv','in_bone','in_emit')])
  self.shadow=ctx.vertex_array(shadow_prog,[(self.vbo,'3f 20x 1f 4x','in_pos','in_bone')])
 def matrices(self,anim,t):
  aa=self.anims[anim];T=aa['length']
  if aa['loop']:t=t%T
  else:t=min(max(t,0),T)
  result={};mat=[]
  for n,b in self.bones.items():
   chs=aa['bones'].get(n,{})
   rot=np.array(b.get('rotation',[0,0,0]))+sample(chs.get('rotation',{'0':[0,0,0]}),t)
   pos=sample(chs.get('position',{'0':[0,0,0]}),t)
   local=transform(rot,b['pivot'],pos)
   world=result[b['parent']]@local if b['parent'] else local
   result[n]=world;mat.append(world)
  return np.array(mat),result
 def bounds(self,anim,t):
  mats,_=self.matrices(anim,t)
  allv=[]
  for c,v in zip(self.cubes,self.cube_rest):
   mm=mats[self.index[c['bone']]]
   allv.append(v@mm[:3,:3].T+mm[:3,3])
  p=np.concatenate(allv);return p.min(0),p.max(0)

VERT='''#version 330
in vec3 in_pos; in vec3 in_normal; in vec2 in_uv; in float in_bone; in float in_emit;
uniform mat4 bones[128];uniform mat4 world;uniform mat4 viewproj;uniform mat4 lightvp;
out vec3 vnormal;out vec3 vworld;out vec2 vuv;out vec4 vlight;out float vemit;
void main(){mat4 m=world*bones[int(in_bone+.5)];vec4 p=m*vec4(in_pos,1.);
vnormal=mat3(m)*in_normal;vworld=p.xyz;vuv=in_uv;vlight=lightvp*p;vemit=in_emit;gl_Position=viewproj*p;}
'''
FRAG='''#version 330
in vec3 vnormal;in vec3 vworld;in vec2 vuv;in vec4 vlight;in float vemit;
uniform sampler2D tex;uniform sampler2DShadow depthtex;uniform int floor_mode;
out vec4 color;
float shadow(){vec3 p=vlight.xyz/vlight.w*.5+.5;if(p.x<0.||p.x>1.||p.y<0.||p.y>1.)return 1.;
float s=0.;for(int x=-1;x<=1;x++)for(int y=-1;y<=1;y++)s+=texture(depthtex,vec3(p.xy+vec2(x,y)/1536.,p.z-.0007));return s/9.;}
void main(){vec4 base=texture(tex,vuv);if(base.a<.5)discard;
if(floor_mode==1)base=vec4(.735,.71,.685,1.);
vec3 n=normalize(vnormal);float key=max(dot(n,normalize(vec3(-.5,1.,-.65))),0.);
float fill=max(dot(n,normalize(vec3(.7,.3,.5))),0.);
float s=shadow();float lit=.40+key*.84*(.23+.77*s)+fill*.25;
vec3 rgb=pow(max(base.rgb,vec3(0.)),vec3(2.2))*lit;
if(vemit>.5)rgb=base.rgb*1.45;
color=vec4(pow(max(rgb,vec3(0.)),vec3(1./2.2)),1.);}
'''
SVERT='''#version 330
in vec3 in_pos;in float in_bone;uniform mat4 bones[128];uniform mat4 world;uniform mat4 lightvp;
void main(){gl_Position=lightvp*world*bones[int(in_bone+.5)]*vec4(in_pos,1.);}
'''
SFRAG='''#version 330
void main(){}
'''

class Renderer:
 def __init__(self,w=900,h=900):
  self.w=w;self.h=h;self.ctx=moderngl.create_standalone_context(backend='egl')
  self.ctx.enable(moderngl.DEPTH_TEST)
  self.prog=self.ctx.program(vertex_shader=VERT,fragment_shader=FRAG)
  self.sprog=self.ctx.program(vertex_shader=SVERT,fragment_shader=SFRAG)
  self.fbo=self.ctx.simple_framebuffer((w,h));self.depth=self.ctx.depth_texture((1536,1536));self.depth.compare_func='<='
  self.depth.repeat_x=False;self.depth.repeat_y=False;self.depth.filter=(moderngl.LINEAR,moderngl.LINEAR)
  self.sfbo=self.ctx.framebuffer(depth_attachment=self.depth)
  self.lightvp=ortho(-51,51,-45,52,1,220)@look([-55,95,-70],[0,18,0])
  self.white=self.ctx.texture((1,1),4,bytes([255,255,255,255]))
  floor=[]
  for v in [[-150,0,-150],[150,0,-150],[150,0,150],[-150,0,-150],[150,0,150],[-150,0,150]]:
   floor.append([*v,0,1,0,0,0,0,0])
  self.fbuf=self.ctx.buffer(np.array(floor,'f4').tobytes())
  self.floor=self.ctx.vertex_array(self.prog,[(self.fbuf,'3f 3f 2f 1f 1f','in_pos','in_normal','in_uv','in_bone','in_emit')])
  self.actors={p.parent.name:Actor(p,self.ctx,self.prog,self.sprog) for p in sorted(BUILD.glob('*/source_model.json'))}
  self.prog['tex']=0;self.prog['depthtex']=1
  self.ident=np.repeat(np.eye(4)[None],128,axis=0)
 def setmat(self,program,name,m):program[name].write(np.asarray(m,dtype='f4').T.tobytes())
 def setbones(self,program,mats):
  mm=self.ident.copy();mm[:len(mats)]=mats
  program['bones'].write(np.transpose(mm,(0,2,1)).astype('f4').tobytes())
 def render(self,key,anim='idle',t=0,angle=22,zoom=1.0):
  a=self.actors[key];mats,_=a.matrices(anim,t)
  height=a.meta.get('render_height',67 if key=='morgrave' else 58 if key=='sullen' else 57 if key!='dredge' else 51)
  target=np.array([0,height*.48 if key!='dredge' else 18,-1 if key!='dredge' else -2.5])
  distance=height*1.85/zoom
  angle=math.radians(angle)
  eye=target+[distance*math.sin(angle),distance*.11,-distance*math.cos(angle)]
  vp=persp(34,self.w/self.h,1,400)@look(eye,target)
  self.sfbo.use();self.ctx.viewport=(0,0,1536,1536);self.sfbo.clear(depth=1.0)
  self.setmat(self.sprog,'lightvp',self.lightvp);self.setmat(self.sprog,'world',np.eye(4));self.setbones(self.sprog,mats)
  a.shadow.render()
  self.fbo.use();self.ctx.viewport=(0,0,self.w,self.h)
  self.fbo.clear(.82,.795,.77,1,depth=1)
  self.setmat(self.prog,'viewproj',vp);self.setmat(self.prog,'lightvp',self.lightvp);self.setmat(self.prog,'world',np.eye(4))
  self.depth.use(1);self.white.use(0);self.setbones(self.prog,[np.eye(4)]);self.prog['floor_mode']=1;self.floor.render()
  self.setbones(self.prog,mats);self.prog['floor_mode']=0;a.texture.use(0);a.vao.render()
  return Image.frombytes('RGB',(self.w,self.h),self.fbo.read(components=3)).transpose(Image.Transpose.FLIP_TOP_BOTTOM)

def font(size,bold=False):
 path='/usr/share/fonts/truetype/dejavu/DejaVuSans-Bold.ttf' if bold else '/usr/share/fonts/truetype/dejavu/DejaVuSans.ttf'
 return ImageFont.truetype(path,size)

def contact_sheets():
 r=Renderer(560,640)
 titles={'idle':'IDLE / HELD STARE','walk':'WALK / RIGID GAIT','perform':'PERFORM / BROKEN ACT','jumpscare':'JUMPSCARE / REACH'}
 for key in ['valek','valek_golden','morgrave','dredge','sullen']:
  sheet=Image.new('RGB',(560*4,730),(232,226,218));d=ImageDraw.Draw(sheet)
  for i,anim in enumerate(titles):
   t={'idle':1.7,'walk':.35,'perform':2.0,'jumpscare':.85}[anim]
   im=r.render(key,anim,t);sheet.paste(im,(i*560,75))
   d.text((i*560+20,687),titles[anim],font=font(18,True),fill=(44,36,39))
  d.text((24,15),r.actors[key].title.upper(),font=font(34,True),fill=(38,30,34))
  d.text((900,27),'ACTUAL MODEL / TEXTURE / ANIMATION RENDER',font=font(20),fill=(88,76,74))
  sheet.save(RENDERS/(key+'_poses.jpg'),quality=93)
  r.render(key,'idle',0).save(RENDERS/(key+'_hero.png'))
  print('Rendered',key,flush=True)

def video():
 r=Renderer(860,860);W=1080;H=1080;fps=20
 out=ROOT.parent/'output'/'Nightcast_Five_Rigid_Animation_Preview.mp4'
 out.parent.mkdir(parents=True,exist_ok=True)
 proc=subprocess.Popen(['ffmpeg','-y','-loglevel','error','-f','rawvideo','-pix_fmt','rgb24','-s',f'{W}x{H}','-r',str(fps),'-i','-','-an','-c:v','libx264','-preset','fast','-crf','20','-pix_fmt','yuv420p','-movflags','+faststart',str(out)],stdin=subprocess.PIPE)
 for key in ['valek','valek_golden','morgrave','dredge','sullen']:
  actor=r.actors[key]
  for k,anim in enumerate(['idle','walk','perform','jumpscare']):
   duration=actor.anims[anim]['length']*(2 if anim=='walk' else 1)
   frames=round(duration*fps)
   for i in range(frames):
    t=i/fps
    im=Image.new('RGB',(W,H),(226,219,211));d=ImageDraw.Draw(im)
    view=r.render(key,anim,t,angle=18 if anim=='jumpscare' else 24)
    im.paste(view,(110,130))
    d.rectangle((0,0,W,123),fill=(30,25,30))
    d.text((52,25),actor.title.upper(),font=font(44,True),fill=(242,233,217))
    d.text((54,82),'NIGHTCAST  /  MINECRAFT BEDROCK',font=font(16),fill=(179,162,150))
    x=45
    for j,label in enumerate(['IDLE','WALK','PERFORM','JUMPSCARE']):
     col=(101,26,41) if j==k else (128,116,110)
     d.rounded_rectangle((x,1015,x+237,1056),radius=4,fill=col)
     tw=d.textlength(label,font=font(17,True));d.text((x+(237-tw)/2,1024),label,font=font(17,True),fill=(249,242,232))
     x+=250
    d.rectangle((0,1073,int(W*(i+1)/frames),1079),fill=(117,30,42))
    proc.stdin.write(im.tobytes())
   print('Video',key,anim,frames,flush=True)
 proc.stdin.close();ret=proc.wait();assert ret==0
 print(out,flush=True)

if __name__=='__main__':
 parser=argparse.ArgumentParser();parser.add_argument('--video',action='store_true');args=parser.parse_args()
 video() if args.video else contact_sheets()

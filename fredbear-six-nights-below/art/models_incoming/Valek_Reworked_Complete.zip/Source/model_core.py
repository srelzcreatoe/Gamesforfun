"""Nightcast reference models. Canonical coordinates: Y up, face -Z.
All joints are rigid. No scale animation or mesh deformation is used.
"""
from pathlib import Path
from collections import OrderedDict
import math, json, uuid, random, base64, io
import numpy as np
from PIL import Image, ImageDraw

ROOT=Path(__file__).resolve().parent
OUT=ROOT/'build'
OUT.mkdir(exist_ok=True)

def uid(s): return str(uuid.uuid5(uuid.NAMESPACE_URL,'nightcast/2026/'+s))
def vec(x): return [round(float(a),5) for a in x]
def dump(path,data):
    path=Path(path);path.parent.mkdir(parents=True,exist_ok=True)
    path.write_text(json.dumps(data,indent=2),encoding='utf-8')

COMMON={
 'steel':(48,48,52), 'metal':(89,88,89), 'edge':(117,113,112),
 'black':(15,14,18),'socket':(8,7,11),'wire':(66,36,39),
 'tooth':(206,193,162),'tooth_tip':(235,223,197),
 'eye':(255,239,232),'eye_rim':(112,62,67),'bow':(30,24,28),
 'bell':(171,117,40), 'red':(93,28,40), 'cream':(166,151,134)
}
PALETTES={
 'valek':dict(shell=(100,91,100),light=(128,117,124),dark=(65,59,68),muzzle=(157,145,145),inner=(51,44,50)),
 'valek_golden':dict(shell=(163,117,36),light=(198,149,54),dark=(102,71,27),muzzle=(201,156,66),inner=(78,55,27)),
 'morgrave':dict(shell=(124,88,59),light=(158,112,70),dark=(80,54,43),muzzle=(170,131,63),inner=(73,35,31),bow=(106,29,38)),
 'dredge':dict(shell=(78,70,78),light=(112,98,108),dark=(47,42,49),muzzle=(116,102,107),inner=(56,42,46)),
 'sullen':dict(shell=(122,39,53),light=(150,53,64),dark=(67,24,34),muzzle=(187,173,151),inner=(58,21,31),bow=(87,28,36))
}

class Model:
 def __init__(self,key,title):
    self.key=key;self.title=title;self.bones=OrderedDict();self.cubes=[]
    self.palette=COMMON|PALETTES[key];self.meta={};self.anims={}
 def bone(self,name,pivot,parent=None):
    assert name not in self.bones,name
    self.bones[name]={'name':name,'pivot':vec(pivot),'parent':parent,'uuid':uid(self.key+'/bone/'+name)}
    return name
 def box(self,bone,name,center,size,mat='shell',rot=None,pivot=None):
    assert bone in self.bones,bone
    c={'name':name,'bone':bone,'center':vec(center),'size':vec(size),'mat':mat,
       'rotation':vec(rot or [0,0,0]),'pivot':vec(pivot if pivot is not None else center),
       'uuid':uid(self.key+'/cube/'+str(len(self.cubes))+'/'+name)}
    assert all(v>0 for v in size)
    self.cubes.append(c);return c
 def shell(self,bone,name,center,size,mat='shell',bevel=.5,rot=None):
    # Three solid stepped cuboids make clean clipped corners, with no coplanar surfaces.
    x,y,z=center; w,h,d=size
    b=min(bevel,w*.18,h*.18,d*.18)
    pivot=center
    self.box(bone,name+'_body',(x,y,z),(w-2*b,h,d-2*b),mat,rot,pivot)
    self.box(bone,name+'_sides',(x,y,z),(w,h-2*b,d-2*b),mat,rot,pivot)
    self.box(bone,name+'_front_back',(x,y,z),(w-2*b,h-2*b,d),mat,rot,pivot)
 def joint(self,bone,name,pos,w=2.4,h=2.4,d=2.4,axis='x'):
    self.shell(bone,name,pos,(w,h,d),'steel',.35)
    if axis=='x':
      for s in [-1,1]:self.box(bone,name+'_axle',np.array(pos)+[s*(w/2+.06),0,0],(.20,h*.58,d*.58),'metal')
    else:self.box(bone,name+'_axle',np.array(pos)+[0,0,-d/2-.06],(w*.5,h*.5,.2),'metal')
 def bolt(self,bone,pos):self.box(bone,'fastener',pos,(.40,.40,.18),'edge')
 def strip(self,bone,name,a,b,width,depth,mat='steel'):
    a=np.array(a);b=np.array(b);v=b-a;L=np.linalg.norm(v)
    # A cuboid whose long local +Y axis is aligned to b-a.
    rx=math.degrees(math.atan2(v[2],math.hypot(v[0],v[1])))
    rz=math.degrees(math.atan2(-v[0],v[1]))
    self.box(bone,name,(a+b)/2,(width,L,depth),mat,[rx,0,rz])

def bow(m,b,p,scale=1):
 x,y,z=p
 m.shell(b,'bow_knot',p,(1.7*scale,1.8*scale,1.05*scale),'bow',.2)
 for s in [-1,1]:
  m.shell(b,'bow_wing',(x+s*1.65*scale,y,z+.08),(2.2*scale,2.9*scale,.9*scale),'bow',.3,[0,0,s*16])

def bear_head(m,parent,p,kind='bear',scale=1):
 """Hollow facial assembly; all teeth belong to the correct hinged jaw."""
 x,y,z=p
 head=m.bone('head',p,parent)
 def B(n,c,sz,mat='shell',rot=None,b=head):
  return m.box(b,n,[x+c[0]*scale,y+c[1]*scale,z+c[2]*scale],[v*scale for v in sz],mat,rot)
 def S(n,c,sz,mat='shell',bevel=.45,rot=None,b=head):
  return m.shell(b,n,[x+c[0]*scale,y+c[1]*scale,z+c[2]*scale],[v*scale for v in sz],mat,bevel*scale,rot)
 skullmat='muzzle' if kind=='rabbit' else 'shell'
 # Empty mouth is not filled with a big head cube. Back and temple plates frame the void.
 S('cranium_back',(0,5.8,1.0),(10.4,8.0,5.0),skullmat)
 B('black_face_recess',(0,5.3,-2.0),(9.3,6.1,1.25),'socket')
 S('forehead',(0,9.2,-1.2),(10.2,2.2,6.2),skullmat)
 for s in [-1,1]:
  S('temple',(s*4.9,5.6,-.8),(2.35,6.1,4.65),skullmat)
  S('cheek',(s*4.15,3.15,-2.35),(3.15,2.2,4.1),'shell')
  B('eye_well',(s*2.65,6.0,-3.27),(3.5,3.5,.42),'socket')
  S('eyebrow',(s*2.67,8.0,-3.1),(3.7,1.15,1.5),'dark',.15,[0,0,-s*6])
  B('eye_socket_lower',(s*2.7,4.36,-3.4),(3.5,.65,.72),'dark')
  B('cheek_edge',(s*4.65,2.6,-3.85),(1.15,1.4,.68),'light')
  m.bolt(head,(x+s*4.95*scale,y+7.5*scale,z-3.35*scale))
 B('nose_bridge',(0,5.8,-3.18),(1.35,3.1,1.5),skullmat)
 for s in [-1,1]:
  S('split_muzzle',(s*1.85,3.1,-4.25),(3.7,2.75,3.35),'muzzle')
  for j in range(3):B('muzzle_pore',(s*(1.2+j*.62),3.35-(j%2)*.5,-5.95),(.20,.20,.10),'dark')
 S('nose',(0,4.45,-5.25),(2.75,1.65,1.60),'black',.25)
 # Eye bones are isolated for the emissive render material.
 eye=m.bone('eyes',(x,y+6*scale,z-3.55*scale),head)
 for s in [-1,1]:
  B('eye_halo',(s*2.6,6,-3.62),(1.16,1.34,.25),'eye_rim',b=head)
  B('eye_light',(s*2.6,6,-3.78),(.64,.76,.20),'eye',b=eye)
 # Upper tooth row and long corner fangs.
 for i in range(10):
  xx=-3.8+i*(7.6/9); length=(1.10 if i in (0,9) else .70+(i%3)*.13)
  B('upper_tooth',(xx,1.48-length*.5,-4.65),(.52,length,.72),'tooth')
  B('upper_tooth_tip',(xx,1.43-length,-4.68),(.30,.30,.45),'tooth_tip')
 jaw=m.bone('jaw',(x,y+1.2*scale,z-.5*scale),head)
 # Side linkage and chin are one rigid moving assembly.
 for s in [-1,1]:
  S('jaw_hinge_cheek',(s*4.15,-.3,-1.5),(1.45,2.7,5.2),'shell',.25,b=jaw)
  B('jaw_hinge_pin',(s*4.94,1.2,-.5),(.5,1.25,1.25),'metal',b=head)
 S('lower_chin',(0,-1.1,-3.45),(8.4,2.0,4.1),'shell',.45,b=jaw)
 B('lower_mouth_floor',(0,-.12,-2.95),(6.9,.35,3.8),'wire',b=jaw)
 for i in range(9):
  xx=-3.5+i*.875; L=.68+(i%3)*.14
  B('lower_tooth',(xx,.04+L*.5,-4.62),(.52,L,.67),'tooth',b=jaw)
  B('lower_tip',(xx,.03+L,-4.66),(.31,.25,.44),'tooth_tip',b=jaw)
 for s in [-1,1]:
  if kind=='rabbit':
   eb=m.bone(('ear_l' if s>0 else 'ear_r'),(x+s*3.7*scale,y+9.8*scale,z),head)
   # Long stepped rabbit ears with visible mechanical break.
   S('ear_base',(s*3.9,12.2,.05),(3.0,5.0,2.35),'shell',.35,[0,0,-s*8],eb)
   B('ear_endoskeleton',(s*4.6,16.8,.1),(1.45,4.4,1.2),'steel',b=eb)
   et=m.bone(('ear_tip_l' if s>0 else 'ear_tip_r'),(x+s*4.6*scale,y+16.0*scale,z),eb)
   S('long_ear_tip',(s*4.7,18.8,.1),(3.1,5.6,2.3),'shell',.4,[0,0,-s*10],et)
   B('ear_inner',(s*4.5,18.7,-1.12),(1.60,4.5,.30),'inner',b=et)
   B('ear_inner',(s*3.9,12.3,-1.22),(1.50,3.3,.28),'inner',b=eb)
  elif kind=='wolf':
   eb=m.bone(('ear_l' if s>0 else 'ear_r'),(x+s*4.1*scale,y+9.4*scale,z+.7*scale),head)
   for j in range(4):
    S('pointed_ear',(s*(4.05+j*.35),10.5+j*1.48,.7),(3.8-j*.8,2.0,2.7-j*.42),'shell',.18,[0,0,-s*12],eb)
   B('ear_inner',(s*4.4,12.4,-.66),(1.2,3.25,.20),'muzzle',b=eb)
  else:
   eb=m.bone(('ear_l' if s>0 else 'ear_r'),(x+s*4.4*scale,y+9.3*scale,z+.7*scale),head)
   S('bear_ear',(s*5.1,11.1,.65),(4.1,4.1,2.6),'shell',.65,[0,0,-s*11],eb)
   S('ear_hollow',(s*5.1,11.1,-.73),(2.35,2.35,.40),'inner',.36,[0,0,-s*11],eb)
 # Damaged contour: a few staggered shell tabs, no loose intersecting fragments.
 for s in [-1,1]:
  B('cheek_tab',(s*5.6,1.5,-1.1),(1.2,2.1,2.0),'dark',[0,0,s*18])
 return head

def fingers(m,parent,x,y,z,side,prefix='',quad=False):
 sign=1 if side=='l' else -1
 for i in range(4):
  xx=x+(-1.65+i*1.1)
  root=f'{prefix}finger_{side}_{i+1}'
  if not quad:
   yy=y-(.0 if i in (1,2) else -.20)
   m.bone(root,(xx,yy,z-.18),parent)
   L=2.4 if i in (1,2) else 2.1
   m.joint(root,'knuckle',(xx,yy,z-.18),.87,.84,1.0)
   m.shell(root,'finger_upper',(xx,yy-L*.5-.35,z-.18),(.91,L,1.12),'shell',.13)
   tip=root+'_tip';m.bone(tip,(xx,yy-L-.35,z-.18),root)
   m.joint(tip,'finger_hinge',(xx,yy-L-.35,z-.18),.75,.72,.82)
   m.shell(tip,'finger_lower',(xx,yy-L-1.16,z-.32),(.77,1.45,.88),'dark',.12)
   m.box(tip,'claw_blade',(xx,yy-L-2.0,z-.60),(.54,1.45,.65),'black',[18,0,0])
   m.box(tip,'claw_point',(xx,yy-L-2.77,z-.85),(.28,.45,.34),'black',[18,0,0])
  else:
   m.bone(root,(xx,y,z),parent)
   m.shell(root,'ground_finger',(xx,y,z-1.3),(1.18,1.55,2.7),'shell',.20)
   tip=root+'_tip';m.bone(tip,(xx,y,z-2.6),root)
   m.box(tip,'paw_claw',(xx,y-.25,z-3.52),(.7,1.0,2.0),'black',[-12,0,0])
   m.box(tip,'paw_claw_point',(xx,y-.43,z-4.6),(.37,.5,.65),'black')
 if not quad:
  tx=x-sign*2.55
  name=f'thumb_{side}';m.bone(name,(tx,y+2.4,z),parent)
  m.shell(name,'thumb_upper',(tx-sign*.3,y+1.1,z-.10),(1.1,2.6,1.4),'shell',.20,[0,0,-sign*18])
  tip=name+'_tip';m.bone(tip,(tx-sign*.55,y-.1,z-.1),name)
  m.box(tip,'thumb_claw',(tx-sign*.60,y-.95,z-.55),(.7,1.8,.92),'black',[22,0,0])

def biped_limbs(m,slim=False):
 aw=3.7 if slim else 4.9
 xarm=8.0 if slim else 9.0
 for s,side in [(-1,'r'),(1,'l')]:
  x=xarm*s
  upper=m.bone('upper_arm_'+side,(x,31.5,0),'torso')
  m.joint(upper,'shoulder_socket',(x,31.5,0),3.0,3.0,3.0)
  m.shell(upper,'shoulder_cap',(x,30.6,0),(aw+1,3.5,5.15),'shell',.5,[0,0,-s*10])
  m.box(upper,'upper_arm_rod',(x,26.6,0),(1.4,8.2,1.7),'steel')
  m.shell(upper,'upper_arm_plate',(x,27.55,-.1),(aw,5.1,4.45),'shell',.45)
  m.box(upper,'arm_outer_strip',(x+s*aw*.45,27.4,.2),(.52,4.4,3.1),'dark')
  m.bolt(upper,(x-s*.95,28.8,-2.40))
  m.bolt(upper,(x+s*.95,26.5,-2.40))
  lower=m.bone('forearm_'+side,(x,22.1,0),upper)
  m.joint(lower,'elbow',(x,22.1,0),3.0,2.55,2.65)
  m.box(lower,'forearm_piston',(x,17.9,.1),(1.3,7.8,1.4),'metal')
  m.shell(lower,'forearm_shell',(x,17.85,-.1),(aw+0.5,6.1,4.8),'shell',.55)
  m.box(lower,'forearm_cuff',(x,14.62,-.05),(aw+.1,1.0,4.3),'dark')
  m.box(lower,'forearm_face',(x,18.1,-2.57),(aw-.6,4.6,.44),'light')
  for j in range(3):m.box(lower,'vent',(x+s*(aw*.38),18+j*.63,-2.82),(.35,.23,.1),'black')
  wrist=m.bone('hand_'+side,(x,13.1,0),lower)
  m.joint(wrist,'wrist',(x,13.1,0),2.65,1.6,2.6)
  m.shell(wrist,'palm',(x,11.0,-.12),(4.75,3.3,2.9),'shell',.40)
  m.box(wrist,'palm_plate',(x,11.15,-1.72),(3.85,2.4,.4),'dark')
  fingers(m,wrist,x,9.6,-.15,side)
  # Legs: anatomical knee bends backward relative to the upper leg;
  # exported animation signs are handled in the exporter.
  x=3.65*s if slim else 4.05*s
  leg=m.bone('thigh_'+side,(x,21,0),'root')
  m.joint(leg,'hip_ball',(x,21,0),3.4,3.3,3.5)
  m.box(leg,'thigh_rod',(x,16,0),(1.6,9.2,1.7),'steel')
  m.shell(leg,'thigh_shell',(x,16.25,0),(4.5 if slim else 5.8,7.5,5.8),'shell',.6)
  m.box(leg,'thigh_front',(x,16.5,-3.08),(3.5 if slim else 4.65,5.8,.5),'light')
  shin=m.bone('shin_'+side,(x,11.4,0),leg)
  m.joint(shin,'knee',(x,11.4,0),3.0,2.3,3.0)
  m.box(shin,'knee_face',(x,11.3,-1.85),(2.9,2.05,.60),'dark')
  m.box(shin,'shin_piston',(x,7,0),(1.7,8.0,1.65),'metal')
  m.shell(shin,'shin_shell',(x,6.65,.15),(4.7 if slim else 5.7,6.3,5.15),'shell',.52)
  m.box(shin,'shin_face',(x,6.8,-2.70),(3.8 if slim else 4.8,5.3,.65),'shell')
  foot=m.bone('foot_'+side,(x,2.8,0),shin)
  m.joint(foot,'ankle',(x,2.8,0),3.0,1.4,3.0)
  m.shell(foot,'foot',(x,1.15,-1.1),(5.6,2.2,6.4),'dark',.3)
  m.box(foot,'instep',(x,2.25,-.4),(4.7,1.45,4.6),'shell')
  for i in range(4):
   xx=x-2.12+i*1.42
   m.shell(foot,'toe',(xx,1.04,-3.55),(1.19,1.95,2.8),'shell',.15)
   m.box(foot,'toe_tip',(xx,.90,-5.06),(.85,1.4,.65),'dark')
 m.meta.update(arm_x=xarm,hip_x=3.65 if slim else 4.05,leg_upper=9.6,leg_lower=8.6,hip_height=21,ankle_height=2.8)

def build_biped(key,title):
 m=Model(key,title);m.bone('root',(0,21,0));m.bone('pelvis',(0,21,0),'root')
 slim=key in ('morgrave','sullen')
 m.joint('pelvis','waist_hub',(0,22,0),5.7,2.8,4.3)
 m.shell('pelvis','pelvic_frame',(0,20.5,0),(10 if not slim else 8.4,3.3,5.9),'dark',.45)
 for s in [-1,1]:m.shell('pelvis','hip_guard',(s*3.5,21.5,-.25),(3.4,3.7,6.35),'shell',.4)
 torso=m.bone('torso',(0,23.4,0),'root')
 m.box(torso,'spine_column',(0,28,.8),(2.3,11,2.3),'steel')
 for y in [24,25.2,26.4,27.6]:m.box(torso,'spine_ring',(0,y,.7),(3.3,.60,3.2),'metal')
 w=11.7 if not slim else 10.0
 m.shell(torso,'back_casing',(0,29.2,1.6),(w,8.3,4.3),'dark',.6)
 if key=='sullen':
  # Patchwork suit with narrow waist and ivory diamond pieces.
  for s in [-1,1]:
   m.shell(torso,'chest_panel',(s*2.7,29.8,-.8),(4.8,7.4,4.0),'shell',.45,[0,0,-s*4])
   for j in range(3):m.box(torso,'ivory_diamond',(s*(1.9+j*.16),27.1+j*1.6,-3.1),(1.6,1.6,.40),'cream',[0,0,45])
  for y in [28.4,30.6,32.4]:m.shell(torso,'button',(0,y,-3.1),(.88,.88,.7),'black',.18)
 elif key=='morgrave':
  for s in [-1,1]:
   m.shell(torso,'broken_chest_shell',(s*4.0,29.7,-.4),(2.7,7.5,5.1),'shell',.4)
   for j in range(4):m.box(torso,'exposed_rib',(s*1.8,26.5+j*1.5,-2.0),(2.75,.75,1.25),'cream',[0,0,-s*5])
  m.box(torso,'sternum',(0,29,-2.25),(1.0,7.1,1.0),'dark')
 else:
  m.shell(torso,'chest_shell',(0,29.7,-.4),(12.4,8.1,6.4),'shell',.72)
  m.shell(torso,'belly_panel',(0,28.7,-3.75),(8.5,6.65,.85),'muzzle',.45)
  for yy in [28.0,30.6]:m.shell(torso,'front_button',(0,yy,-4.34),(.72,.72,.5),'black',.12)
  # Gaps in lower shell expose a complete rigid endoskeleton.
  for s in [-1,1]:m.box(torso,'lower_shell_tab',(s*4.2,25.1,-.4),(2.8,2.4,4.9),'dark',[0,0,s*6])
 neck=m.bone('neck',(0,33,0),torso)
 m.box(neck,'neck_piston',(0,35.6,0),(2.2,7.2,2.4),'metal')
 for yy in [33.3,34.6,35.5,36.7,37.6,38.6]:m.box(neck,'neck_ring',(0,yy,0),(3.65,.68,3.65),'steel')
 bow(m,torso,(0,32.65,-3.9),.90 if slim else .85)
 if key=='sullen':build_jester_head(m,neck,(0,38.8,0))
 else:bear_head(m,neck,(0,38.8,-1.2),'rabbit' if key=='morgrave' else 'bear')
 biped_limbs(m,slim)
 if key=='sullen':
  # Rigid ruff and small shoulder ruffles.
  for s in [-1,1]:
   for j in range(3):
    m.box(torso,'ruff_point',(s*(2.0+j*1.1),33.1-j*.45,-2.2),(2.0,2.7,1.2),'shell',[0,0,s*(22+j*12)])
   upper='upper_arm_'+('l' if s>0 else 'r')
   for j in range(3):m.box(upper,'shoulder_ruff',(s*(7.7+j*.95),31.4-j*.48,-1.4),(1.7,2.0,3.0),'dark',[0,0,-s*14])
 if key=='valek_golden':
  # Separate damage layout, not a palette-only asset.
  for s in [-1,1]:
   m.box('torso','ragged_gold_edge',(s*5.65,26.9,1.0),(1.1,2.2,2.4),'light',[0,0,s*8])
  m.box('head','forehead_patch',(-2.1,48.1,-4.2),(2.7,1.4,.6),'dark')
 m.meta['kind']='biped';return m

def build_jester_head(m,parent,p):
 x,y,z=p;head=m.bone('head',p,parent)
 m.shell(head,'black_head_frame',(0,y+5.0,.5),(9.7,10.8,6.6),'dark',.6)
 m.box(head,'face_void',(0,y+5.0,-3.02),(8.8,8.6,.85),'socket')
 # Four offset ivory mask sections leave unmistakable black eye cavities.
 m.shell(head,'mask_forehead',(0,y+9.1,-3.1),(8.65,2.2,1.9),'muzzle',.45)
 for s in [-1,1]:
  m.shell(head,'mask_temple',(s*4.1,y+5.5,-2.6),(1.55,6.4,2.7),'muzzle',.35)
  m.shell(head,'mask_cheek',(s*2.9,y+2.65,-3.35),(2.7,2.5,1.8),'muzzle',.4)
  m.box(head,'eye_border',(s*2.3,y+6.1,-3.56),(2.7,3.8,.44),'black')
  m.box(head,'brow_ridge',(s*2.4,y+8.23,-3.75),(2.7,.75,.70),'cream',[0,0,-s*9])
  for j in range(3):m.box(head,'tear_mark',(s*(2.45+.1*j),y+3.85-j*.48,-4.14),(.55,.68,.15),'black')
 m.box(head,'mask_nose_bridge',(0,y+5.7,-3.74),(1.4,3.3,1.25),'muzzle')
 m.shell(head,'small_black_nose',(0,y+4.15,-4.4),(1.3,1.35,1.2),'black',.2)
 m.shell(head,'upper_lip',(0,y+2.1,-3.67),(4.3,.8,1.1),'cream',.2)
 eyes=m.bone('eyes',(0,y+6.1,-3.95),head)
 for s in [-1,1]:
  m.box(head,'eye_halo',(s*2.2,y+6.1,-3.9),(1.05,1.15,.20),'eye_rim')
  m.box(eyes,'eye_light',(s*2.2,y+6.1,-4.06),(.52,.64,.18),'eye')
 for i in range(8):m.box(head,'upper_tooth',(-2.30+i*.66,y+1.30,-3.9),(.43,.86,.55),'tooth')
 jaw=m.bone('jaw',(0,y+1.4,.10),head)
 for s in [-1,1]:m.box(jaw,'jaw_link',(s*3.4,y-.2,-1.6),(.85,2.6,4.4),'steel')
 m.shell(jaw,'chin_mask',(0,y-.78,-2.8),(6.75,2.4,3.6),'muzzle',.4)
 m.box(jaw,'chin_paint',(0,y-1.45,-4.7),(2.1,.85,.15),'shell')
 for i in range(8):m.box(jaw,'lower_tooth',(-2.30+i*.66,y+.5,-3.9),(.43,.68,.55),'tooth')
 # Jointed fabric-shaped cap: rigid segments, never elastic or rubbery.
 m.shell(head,'cap_band',(0,y+10.2,.4),(10.5,2.0,7.0),'shell',.55)
 for s,side in [(1,'l'),(-1,'r')]:
  hb=m.bone('hat_'+side,(s*3.0,y+10.9,.5),head)
  for j in range(3):
   m.shell(hb,'cap_rise',(s*(3.5+j*.9),y+11.5+j*.55,.4),(4.5-j*.35,3.1-j*.22,5.4-j*.6),'shell',.35,[0,0,-s*(16+j*14)])
  tip=m.bone('hat_tip_'+side,(s*6.5,y+12.1,.4),hb)
  for j in range(4):
   m.shell(tip,'cap_droop',(s*(7.0+j*.47),y+11.2-j*1.6,.3),(2.75-j*.47,2.3,3.4-j*.60),'dark' if (j+int(s))%3==0 else 'shell',.23,[0,0,s*12])
  bell=m.bone('bell_'+side,(s*8.55,y+5.1,.3),tip)
  m.box(bell,'bell_hanger',(s*8.55,y+4.9,.3),(.40,1.3,.40),'metal')
  m.shell(bell,'gold_bell',(s*8.55,y+3.95,.3),(1.8,2.0,1.8),'bell',.43)
  m.box(bell,'bell_slit',(s*8.55,y+3.4,-.62),(.24,.9,.12),'black')

def build_dredge():
 m=Model('dredge','Dredge');m.bone('root',(0,18,5));m.bone('pelvis',(0,18,8),'root')
 m.shell('pelvis','haunch_core',(0,16.5,9),(12.5,10.5,10.0),'dark',.8)
 torso=m.bone('torso',(0,20,5),'root')
 m.shell(torso,'barrel_endoskeleton',(0,21.1,1.0),(15.5,11.8,18.8),'steel',1.0)
 m.shell(torso,'back_shell',(0,26,2),(15.8,4.6,19.2),'shell',.7)
 for s in [-1,1]:
  for j in range(5):
   m.shell(torso,'overlapping_rib_plate',(s*(7.9-.25*j),22.0-j*.35,-5+j*3.4),(3.5,8.6,3.2),'shell',.35,[0,0,s*(12+j*2)])
  for j in range(4):m.box(torso,'exposed_rib',(s*6.3,18.9,-4+j*3.4),(1.1,5.6,1.1),'metal',[0,0,s*16])
 for j in range(7):
  z=-5+j*2.8
  m.shell(torso,'spinal_plate',(0,28.8,z),(3.5,3.5,3.1),'dark',.4,[15,0,0])
  m.box(torso,'spine_fin',(0,31.0,z+.5),(1.75,2.7,2.3),'shell',[27,0,0])
  for s in [-1,1]:m.box(torso,'back_spur',(s*4.4,28.5,z),(1.6,3.9,1.85),'dark',[22,0,-s*25])
 neck=m.bone('neck',(0,24,-8),torso)
 m.shell(neck,'neck_frame',(0,23.5,-9),(7.5,7.0,6.8),'steel',.6)
 bear_head(m,neck,(0,21.8,-11),'wolf',1.06)
 # Layered jaw and cheek spurs give the wolf a deeper skull silhouette.
 for s in [-1,1]:
  for j in range(3):m.box('head','mane_shard',(s*(6+j*.65),25-j*1.7,-8.0),(2.1,4.3,2.3),'shell',[0,0,s*(15+j*12)])
 for s,side in [(-1,'r'),(1,'l')]:
  for front in [True,False]:
   prefix='front' if front else 'rear'
   xx=s*(9.4 if front else 6.8);yy=22.8 if front else 17.6;zz=-5.2 if front else 10.1
   knee=12.7 if front else 10.0
   up=m.bone(f'{prefix}_upper_{side}',(xx,yy,zz),'root')
   m.joint(up,'shoulder' if front else 'hip',(xx,yy,zz),4.2,4.2,4.3)
   m.shell(up,'limb_armor',(xx,(yy+knee)/2+.1,zz),(6.5 if front else 6.0,yy-knee-1.0,6.4),'shell',.65)
   m.box(up,'limb_panel',(xx,(yy+knee)/2,zz-3.37),(5.1,yy-knee-2.0,.7),'light')
   for j in range(3):m.box(up,'side_fur_plate',(xx+s*3.0,yy-2.5-j*1.7,zz+.2),(1.5,3.6,4.3),'dark',[0,0,-s*15])
   lo=m.bone(f'{prefix}_lower_{side}',(xx,knee,zz),up)
   m.joint(lo,'elbow',(xx,knee,zz),3.5,2.8,3.2)
   m.shell(lo,'forearm',(xx,(knee+3)/2,zz),(5.4,knee-4.2,5.7),'shell',.6)
   m.box(lo,'forearm_slab',(xx,(knee+3)/2,zz-3),(4.4,knee-5,.7),'shell')
   paw=m.bone(f'{prefix}_paw_{side}',(xx,2.8,zz),lo)
   m.joint(paw,'paw_wrist',(xx,2.8,zz),3.2,1.8,3.0)
   m.shell(paw,'paw',(xx,1.5,zz-1.0),(6.6,2.65,5.0),'dark',.35)
   m.box(paw,'paw_upper',(xx,2.2,zz-1.0),(5.8,1.5,4.3),'shell')
   fingers(m,paw,xx,1.18,zz-3.4,side,prefix+'_',True)
 tail=m.bone('tail',(0,21,12),'root')
 m.shell(tail,'tail_stub',(0,21.3,14),(4.1,3.8,6.2),'dark',.5,[12,0,0])
 m.box(tail,'tail_plate',(0,22.1,15.3),(2.7,3.2,3.4),'shell',[15,0,0])
 m.meta={'kind':'quadruped','front_upper':10.1,'front_lower':9.9,'rear_upper':7.6,'rear_lower':7.2}
 return m

FACES=['north','south','east','west','up','down']
def face_size(c,face):
 w,h,d=c['size']
 return (w,h) if face in ['north','south'] else (d,h) if face in ['east','west'] else (w,d)

def make_texture(m):
 # A cached, packed per-face atlas avoids stretching on small non-integer geometry.
 keys={}
 for ci,c in enumerate(m.cubes):
  c['face_keys']={}
  for fi,f in enumerate(FACES):
   w,h=face_size(c,f);pw=max(2,math.ceil(w*3));ph=max(2,math.ceil(h*3))
   k=(c['mat'],pw,ph,(ci+fi)%3)
   keys[k]=None;c['face_keys'][f]=k
 def pack(sz):
  x=y=1;rh=0;places={}
  for k in sorted(keys,key=lambda k:(-k[2],-k[1],k[0])):
   w,h=k[1:3]
   if x+w+1>sz:x=1;y+=rh+2;rh=0
   if y+h+1>sz:return None
   places[k]=(x,y);x+=w+2;rh=max(rh,h)
  return places
 size=256;places=pack(size)
 while places is None:size*=2;places=pack(size)
 atlas=Image.new('RGBA',(size,size),(0,0,0,0));r=random.Random(9273)
 for key,(u,v) in places.items():
  mat,w,h,var=key;base=np.array(m.palette[mat],float)
  a=np.zeros((h,w,4),dtype=np.uint8)
  for yy in range(h):
   for xx in range(w):
    noise=r.randint(-3,3) if mat not in ('eye','socket','black') else 0
    factor=1.0+noise/100
    if mat in ('shell','light','dark','muzzle','cream','red'):
     # Narrow pixel seams at a consistent scale, with stronger outer edge wear.
     gx=(xx+var*2)%6;gy=(yy+var)%6
     if (gx==0 or gy==0) and min(w,h)>7:factor*=.84
     elif (gx==1 or gy==1) and min(w,h)>7:factor*=1.035
     if xx==0 or yy==0:factor*=1.12
     if xx==w-1 or yy==h-1:factor*=.72
     if r.random()<.025:factor*=.76
    elif mat in ('steel','metal','edge','bell'):
     if xx==0 or yy==0:factor*=1.28
     if xx==w-1 or yy==h-1:factor*=.68
     if yy%5==0:factor*=.93
    elif mat.startswith('tooth'):
     factor*=.94+.1*yy/max(h-1,1)
    a[yy,xx,:3]=np.clip(base*factor,0,255).astype(np.uint8);a[yy,xx,3]=255
  tile=Image.fromarray(a)
  atlas.paste(tile,(u,v))
  # Duplicate edge texels into the gutter to prevent seams at mip levels.
  atlas.paste(tile.resize((w+2,h+2),Image.Resampling.NEAREST),(u-1,v-1))
  atlas.paste(tile,(u,v))
 for c in m.cubes:
  c['uv']={f:[*places[k],k[1],k[2]] for f,k in c.pop('face_keys').items()}
 m.meta['texture_size']=size
 path=OUT/m.key/f'{m.key}.texture.png';path.parent.mkdir(parents=True,exist_ok=True)
 atlas.save(path);return path

def export_geo(m):
 bones=[]
 for name,b in m.bones.items():
  bb={'name':name,'pivot':[-b['pivot'][0],b['pivot'][1],b['pivot'][2]]}
  if b['parent']:bb['parent']=b['parent']
  if any(b.get('rotation',[0,0,0])):
   br=b['rotation'];bb['rotation']=[-br[0],-br[1],br[2]]
  cubes=[]
  for c in m.cubes:
   if c['bone']!=name:continue
   cen=np.array(c['center']);size=np.array(c['size']);a=cen-size/2;end=cen+size/2
   cube={'origin':vec([-end[0],a[1],a[2]]),'size':vec(size),'uv':{}}
   for f,uv in c['uv'].items():
    # Blockbench's Bedrock codec preserves face names while mirroring X.
    u,v,w,h=uv
    if f in ('up','down'):cube['uv'][f]={'uv':[u+w,v+h],'uv_size':[-w,-h]}
    else:cube['uv'][f]={'uv':[u,v],'uv_size':[w,h]}
   if any(c['rotation']):
    cube['pivot']=[-c['pivot'][0],c['pivot'][1],c['pivot'][2]]
    cube['rotation']=[-c['rotation'][0],-c['rotation'][1],c['rotation'][2]]
   cubes.append(cube)
  if cubes:bb['cubes']=cubes
  bones.append(bb)
 size=m.meta['texture_size']
 return {'format_version':'1.12.0','minecraft:geometry':[{'description':{
  'identifier':'geometry.nightcast.'+m.key,'texture_width':size,'texture_height':size,
  'visible_bounds_width':6,'visible_bounds_height':7,'visible_bounds_offset':[0,2,0]},'bones':bones}]}

def export_bbmodel(m):
 elements=[]
 for c in m.cubes:
  lo=np.array(c['center'])-np.array(c['size'])/2;hi=np.array(c['center'])+np.array(c['size'])/2
  e={'name':c['name'],'type':'cube','uuid':c['uuid'],'from':vec(lo),'to':vec(hi),
     'origin':c['pivot'],'rotation':c['rotation'],'box_uv':False,'rescale':False,'autouv':0,'locked':False,'color':0,
     'faces':{f:{'uv':[u,v,u+w,v+h],'texture':0} for f,(u,v,w,h) in c['uv'].items()}}
  elements.append(e)
 def group(name):
  b=m.bones[name]
  return {'name':name,'origin':b['pivot'],'rotation':b.get('rotation',[0,0,0]),'uuid':b['uuid'],'export':True,
   'isOpen':False,'visibility':True,'autouv':0,'children':
     [c['uuid'] for c in m.cubes if c['bone']==name]+[group(n) for n,x in m.bones.items() if x['parent']==name]}
 texpath=OUT/m.key/f'{m.key}.texture.png'
 tex64=base64.b64encode(texpath.read_bytes()).decode()
 animations=[]
 for aname,anim in m.anims.items():
  animators={}
  for bn,channels in anim['bones'].items():
   frames=[]
   for ch,keys in channels.items():
    for t,v in keys.items():
     frames.append({'channel':ch,'data_points':[dict(zip('xyz',[str(x) for x in v]))],
       'uuid':uid(f'{m.key}/{aname}/{bn}/{ch}/{t}'),'time':float(t),'color':-1,'interpolation':'linear'})
   animators[m.bones[bn]['uuid']]={'name':bn,'type':'bone','keyframes':frames}
  animations.append({'uuid':uid(m.key+'/'+aname),'name':f'animation.nightcast.{m.key}.{aname}',
    'loop':'loop' if anim['loop'] else 'hold','override':False,'length':anim['length'],'snapping':40,
    'animators':animators})
 size=m.meta['texture_size']
 return {'meta':{'format_version':'4.10','model_format':'bedrock','box_uv':False},
   'name':m.title,'model_identifier':'nightcast.'+m.key,'visible_box':[6,7,2],
   'resolution':{'width':size,'height':size},'elements':elements,
   'outliner':[group(n) for n,b in m.bones.items() if b['parent'] is None],
   'textures':[{'path':f'{m.key}.texture.png','name':f'{m.key}.texture.png','id':'0','uuid':uid(m.key+'/texture'),
    'source':'data:image/png;base64,'+tex64,'mode':'bitmap','saved':True,'visible':True,'render_mode':'default',
    'particle':False,'use_as_default':True}], 'animations':animations}

def export_animations(m):
 out={}
 for name,a in m.anims.items():
  bones={}
  for bn,chs in a['bones'].items():
   bones[bn]={}
   for ch,keys in chs.items():
    converted={}
    for t,v in keys.items():
     converted[t]=[-v[0],-v[1],v[2]] if ch=='rotation' else [-v[0],v[1],v[2]] if ch=='position' else v
    bones[bn][ch]=converted
  out[f'animation.nightcast.{m.key}.{name}']={'loop':True if a['loop'] else 'hold_on_last_frame','animation_length':a['length'],'bones':bones}
 return {'format_version':'1.8.0','animations':out}

def build_all():
 return [build_biped('valek','Valek'),build_biped('valek_golden','Valek (Golden)'),build_biped('morgrave','Morgrave'),build_dredge(),build_biped('sullen','Sullen')]

if __name__=='__main__':
 from animate_models import animate
 models=build_all()
 for m in models:
  make_texture(m);animate(m)
  dump(OUT/m.key/f'{m.key}.geo.json',export_geo(m))
  dump(OUT/m.key/f'{m.key}.animation.json',export_animations(m))
  dump(OUT/m.key/f'{m.key}.bbmodel',export_bbmodel(m))
  dump(OUT/m.key/'source_model.json',{'key':m.key,'title':m.title,'bones':m.bones,'cubes':m.cubes,'meta':m.meta,'anims':m.anims})
  print(m.title,len(m.cubes),'cubes',len(m.bones),'bones',m.meta['texture_size'],'texture')

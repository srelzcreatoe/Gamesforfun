"""Valek-only revision: longer bulkier chassis, straight brows and inward hands.
Hand rest yaw follows the user's freddy_v6.bbmodel: X-positive +90, X-negative -90.
Fredbear V6's free left hand uses a comparable inward (-60) turn; no props copied.
"""
from pathlib import Path
from collections import OrderedDict
import json,math
import numpy as np
import model_core as core
import animation_core as anim

ROOT=Path(__file__).resolve().parent;core.OUT=ROOT/'build'

def sub(m,n):
 found={n}
 while True:
  extra={b['name'] for b in m.bones.values() if b['parent'] in found}
  if extra.issubset(found):return found
  found|=extra

def affine(m,names,scale,origin=(0,0,0),offset=(0,0,0)):
 s=np.array(scale);o=np.array(origin);d=np.array(offset)
 def point(p):return core.vec((np.array(p)-o)*s+o+d)
 for name in names:m.bones[name]['pivot']=point(m.bones[name]['pivot'])
 for c in m.cubes:
  if c['bone'] in names:
   c['center']=point(c['center']);c['pivot']=point(c['pivot']);c['size']=core.vec(np.array(c['size'])*s)

def mirror_thumb(m,side,xc):
 names=sub(m,'thumb_'+side)
 for name in names:m.bones[name]['pivot'][0]=round(2*xc-m.bones[name]['pivot'][0],5)
 for c in m.cubes:
  if c['bone'] in names:
   for k in ['center','pivot']:c[k][0]=round(2*xc-c[k][0],5)
   c['rotation'][1]*=-1;c['rotation'][2]*=-1

def geometry():
 m=core.build_biped('valek','Valek — Reworked')
 # Preserve the pelvis and leg heights; give the torso 48% more vertical length.
 affine(m,{'torso'},[1.28,1.48,1.28],origin=[0,23.4,0])
 affine(m,{'pelvis'},[1.23,1.05,1.2],origin=[0,21,0])
 neck=sub(m,'neck')
 affine(m,neck,[1,1,1],offset=[0,4.608,-.9])
 head=sub(m,'head');pivot=m.bones['head']['pivot'][:]
 affine(m,head,[1.075,1.05,1.08],origin=pivot,offset=[0,.7,-.65])
 for side,s in [('l',1),('r',-1)]:
  # Broad shoulders and thicker shell pieces, with longer arm segments.
  xold=9*s;xnew=11.65*s
  shoulder_old=31.5;shoulder_new=35.388
  elbow_old=22.1;elbow_new=shoulder_new-9.4*1.15
  wrist_old=13.1;wrist_new=elbow_new-9.0*1.15
  affine(m,{'upper_arm_'+side},[1.21,1.15,1.23],origin=[xold,shoulder_old,0],offset=[xnew-xold,shoulder_new-shoulder_old,0])
  affine(m,{'forearm_'+side},[1.21,1.15,1.23],origin=[xold,elbow_old,0],offset=[xnew-xold,elbow_new-elbow_old,0])
  handnames=sub(m,'hand_'+side)
  affine(m,handnames,[1.10,1.04,1.12],origin=[xold,wrist_old,0],offset=[xnew-xold,wrist_new-wrist_old,0])
  # Move the thumb to the same pre-twist side as the Freddy reference.
  mirror_thumb(m,side,xnew)
  # A wrist animator and a fixed hand mount keep the 90-degree twist stable.
  hand=m.bones['hand_'+side];oldparent=hand['parent'];hand['parent']='wrist_'+side
  newbone={'name':'wrist_'+side,'pivot':hand['pivot'][:],'parent':oldparent,'uuid':core.uid('valek/bone/wrist_'+side)}
  revised=OrderedDict()
  for n,b in m.bones.items():
   if n=='hand_'+side:revised[newbone['name']]=newbone
   revised[n]=b
  m.bones=revised;hand['rotation']=[0,90*s,0]
  # Palm armor sits on the back; the fingers curl toward the palm side.
  for c in m.cubes:
   if c['bone']=='hand_'+side and c['name']=='palm_plate':
    c['center'][2]=abs(c['center'][2]);c['pivot'][2]=c['center'][2]
  leg=sub(m,'thigh_'+side)
  affine(m,leg,[1.16,1.0,1.18],origin=[4.05*s,21,0],offset=[.90*s,0,0])
 # Straight, level individual eyebrows. Head tilt never changes their relative angle.
 for c in m.cubes:
  if c['name'].startswith('eyebrow'):
   c['rotation']=[0,0,0];c['size'][1]*=.84;c['size'][2]*=1.18
   c['center'][1]-=.17;c['pivot']=c['center'][:]
  if c['mat']=='eye':
   c['size'][0]*=.68;c['size'][1]*=.74
  if c['name']=='eye_halo':c['size'][0]*=.75;c['size'][1]*=.78
  if c['name'].startswith('upper_tooth') and abs(c['center'][0])>3.3:
   c['size'][0]*=.84
  if c['name']=='muzzle_pore':c['size'][0]*=.8;c['size'][1]*=.8
 # Weighty, distressed shoulder plates; seams expose dark rigid structure.
 for side,s in [('l',1),('r',-1)]:
  b='upper_arm_'+side;x=m.bones[b]['pivot'][0];y=m.bones[b]['pivot'][1]
  m.shell(b,'outer_shoulder_plate',(x+s*2.6,y-1.2,.2),(2.2,4.2,5.7),'dark',.3,[0,0,-s*7])
  m.box(b,'shoulder_rim',(x,y+.3,-2.6),(5.45,.62,1.7),'light')
  # Large mechanical back-of-hand plate and visible two screw heads.
  hand='hand_'+side;hx,hy,hz=m.bones[hand]['pivot']
  for dx in [-1.32,1.32]:m.box(hand,'palm_back_screw',(hx+dx,hy-2.0,1.94),(.36,.36,.18),'metal')
 # Extra abdomen panels make the extended torso read as a long chassis.
 for s in [-1,1]:
  m.shell('torso','lower_abdomen_panel',(s*3.25,26.65,-3.15),(4.9,4.15,2.05),'dark',.3,[0,0,s*3])
  m.box('torso','abdomen_edge',(s*5.0,26.6,-3.2),(.75,3.6,2.35),'shell')
 # Thin charcoal tears sit around the recessed eyes without changing the silhouette.
 H=m.bones['head']['pivot'];sx=1.075;sy=1.05;sz=1.08
 for s in [-1,1]:
  for j in range(3):
   m.box('head','eye_stain',(s*(3.75-.1*j)*sx,H[1]+(4.4-j*.52)*sy,H[2]-3.79*sz),(.32,.7,.16),'dark')
 # Rear throat casing conceals the back of the tooth row while preserving the hinge.
 m.shell('head','rear_throat_casing',(0,H[1]+1.8,H[2]+2.4),(8.6,3.0,1.45),'dark',.35)
 for s in [-1,1]:
  m.box('head','rear_jaw_motor',(s*3.35,H[1]+1.0,H[2]+1.4),(1.5,2.3,2.4),'steel')
 # One missing front tooth and understated damaged seams interrupt the even grin.
 missing=min([c['center'][0] for c in m.cubes if c['name']=='upper_tooth' and c['center'][0]>0],key=lambda x:abs(x-1.4))
 m.cubes=[c for c in m.cubes if not(c['name'].startswith('upper_tooth') and abs(c['center'][0]-missing)<.01)]
 for s in [-1,1]:
  for j in range(3):m.box('torso','chest_fracture',(s*(4.0+j*.55),30.8+j*.65,-5.40),(.55,.21,.15),'dark')
 # Lengthen the complete torso a further 30% while keeping the waist fixed.
 # Move the attached rigid assemblies to their new mounting positions.
 torso_bottom=22.068;extra_length=1.30
 torso_hinge=m.bones['torso']['pivot'][:]
 affine(m,{'torso'},[1,extra_length,1],origin=[0,torso_bottom,0])
 m.bones['torso']['pivot']=torso_hinge
 for c in m.cubes:
  if c['bone']=='torso' and c['name'].startswith(('bow_','front_button','spine_ring','chest_fracture')):
   c['size'][1]=round(c['size'][1]/extra_length,5)
 for mount in ['neck','upper_arm_l','upper_arm_r']:
  rise=(m.bones[mount]['pivot'][1]-torso_bottom)*(extra_length-1)
  affine(m,sub(m,mount),[1,1,1],offset=[0,rise,0])
 m.palette.update(shell=(88,83,94),light=(118,109,121),dark=(48,43,54),muzzle=(140,129,134),
   eye_rim=(82,57,63),wire=(35,20,28),tooth=(180,173,157),tooth_tip=(222,215,192))
 m.meta.update(arm_x=11.65,hip_x=4.95,render_height=69.0,revision='Valek only / torso lengthened another 30% / inward palms',
   proportions={'torso_length_factor':1.924,'torso_length_from_previous_revision':1.30,'torso_width_factor':1.28,'torso_depth_factor':1.28,'arm_length_factor':1.15,'leg_width_factor':1.16},
   hand_reference={'source':'freddy_v6.bbmodel','positive_x_yaw':90,'negative_x_yaw':-90,'thumb_direction':'forward'})
 return m

def curve(u,points):return anim.scalar(u,points)

def custom_pose(m,which,t,T):
 if which=='idle':q,p,feet=anim.idle(m,t,T)
 elif which=='walk':q,p,feet=anim.walking(m,t,T)
 elif which=='perform':q,p,feet=anim.perform(m,t,T)
 else:q,p,feet=anim.jumpscare(m,t,T)
 u=t/T
 if which=='idle':
  # Long motionless stare; only a small deliberate ratchet late in the loop.
  yaw=curve(u,[(0,0),(.30,0),(.35,7),(.56,7),(.575,5),(.76,5),(.83,-4),(.94,-4),(1,0)])
  tilt=curve(u,[(0,0),(.48,0),(.52,-5),(.74,-5),(.79,-2),(.92,-2),(1,0)])
  q['torso']=[-5,0,0];q['head']=[1,yaw,tilt]
  q['jaw']=[-20,0,0]
 elif which=='walk':
  q['torso'][0]=-7;q['head'][0]=4;q['head'][2]*=.35;q['jaw'][0]=-20
 elif which=='perform':
  # Uneven presentation gesture, with an unwavering held face between turns.
  turn=curve(u,[(0,0),(.18,0),(.25,1),(.48,1),(.56,-.6),(.76,-.6),(.93,0),(1,0)])
  q['head'][0]=2;q['head'][1]=-14*turn;q['head'][2]=5*turn
  q['jaw'][0]-=2
 else:
  attack=curve(u,[(0,0),(.21,0),(.27,-.12),(.31,-.12),(.375,1),(.61,1),(.66,.92),(.70,1),(.84,1),(1,0)])
  opening=curve(u,[(0,0),(.27,0),(.37,1),(.80,1),(1,0)])
  q['torso']=[-5-attack*13,0,0];q['head']=[1+attack*12,0,0]
  q['jaw']=[-20-opening*27,0,0]
  p[1]=-.85-max(0,attack)*.62
  for side,s in [('l',1),('r',-1)]:
   q['upper_arm_'+side]=[-3+attack*70,0,s*(8+max(0,attack)*18)]
   q['forearm_'+side]=[10+max(0,attack)*18,0,0]
   for i in range(4):
    q[f'finger_{side}_{i+1}']=[10+i*1.4+max(0,attack)*10,0,s*(i-1.5)*(1.5+max(0,attack)*2)]
    q[f'finger_{side}_{i+1}_tip']=[18+i+max(0,attack)*11,0,0]
 # Hands retain the fixed, mirrored yaw in every animation.
 for side,s in [('l',1),('r',-1)]:
  wrist=q['hand_'+side][:]
  wrist[0]*=.45;wrist[1]=0;wrist[2]*=.40
  q['wrist_'+side]=wrist;q['hand_'+side]=[0,0,0]
  q['thumb_'+side][2]*=-1
  q['thumb_'+side+'_tip'][2]*=-1
 anim.solve_feet(m,q,p,feet,which,t,T)
 return q,p

def animate(m):
 for name,T,loop in [('idle',8.0,True),('walk',1.95,True),('perform',7.2,True),('jumpscare',2.5,False)]:
  # Pre-existing perform/idle logic works in normalized time; walk uses its new period.
  bones={n:{'rotation':{}} for n in m.bones};bones['root']['position']={}
  steps=round(T*40)
  for i in range(steps+1):
   t=round(T*i/steps,5);tt=0 if i==steps and loop else t
   q,p=custom_pose(m,name,tt,T);key=f'{t:.5f}'.rstrip('0').rstrip('.') or '0'
   for n,v in q.items():bones[n]['rotation'][key]=[round(float(x),4) for x in v]
   bones['root']['position'][key]=[round(float(x),4) for x in p]
  for n,channels in bones.items():
   for ch,keys in channels.items():
    seq=list(keys.items());keep=[seq[0]]
    for i in range(1,len(seq)-1):
     t0,v0=keep[-1];t1,v1=seq[i];t2,v2=seq[i+1]
     f=(float(t1)-float(t0))/(float(t2)-float(t0));expected=np.array(v0)*(1-f)+np.array(v2)*f
     if np.max(np.abs(expected-v1))>.002:keep.append(seq[i])
    keep.append(seq[-1]);channels[ch]=dict(keep)
  m.anims[name]={'length':T,'loop':loop,'bones':bones}

def main():
 m=geometry();core.make_texture(m);animate(m)
 dr=core.OUT/'valek'
 core.dump(dr/'valek.geo.json',core.export_geo(m));core.dump(dr/'valek.animation.json',core.export_animations(m))
 core.dump(dr/'valek.bbmodel',core.export_bbmodel(m))
 core.dump(dr/'source_model.json',{'key':m.key,'title':m.title,'bones':m.bones,'cubes':m.cubes,'meta':m.meta,'anims':m.anims})
 print('Valek:',len(m.cubes),'cubes,',len(m.bones),'bones,',len(m.anims),'animations')

if __name__=='__main__':main()

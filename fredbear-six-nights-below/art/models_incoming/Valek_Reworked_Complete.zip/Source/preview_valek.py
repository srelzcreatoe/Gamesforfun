from pathlib import Path
import argparse,subprocess,math
from PIL import Image,ImageDraw,ImageFont
import render_core as rc

ROOT=Path(__file__).resolve().parent
OUT=ROOT.parent/'output'/'valek';OUT.mkdir(exist_ok=True)
rc.BUILD=ROOT/'build';rc.RENDERS=ROOT/'renders';rc.RENDERS.mkdir(exist_ok=True)

def font(n,bold=False):return ImageFont.truetype('/usr/share/fonts/truetype/dejavu/DejaVuSans'+('-Bold' if bold else '')+'.ttf',n)

def stills():
 r=rc.Renderer(660,840)
 sheet=Image.new('RGB',(2640,960),(231,225,216));d=ImageDraw.Draw(sheet)
 clips=[('idle',1.,20),('walk',.42,20),('perform',2.3,20),('jumpscare',1.03,20)]
 for i,(name,t,angle) in enumerate(clips):
  im=r.render('valek',name,t,angle=angle,zoom=.94);sheet.paste(im,(i*660,83))
  d.text((i*660+23,920),name.upper(),font=font(22,True),fill=(44,33,39))
 d.text((25,20),'VALEK / REWORKED',font=font(37,True),fill=(41,31,36))
 d.text((880,35),'LONGER TORSO / HEAVIER CHASSIS / INWARD HANDS',font=font(24),fill=(90,77,79))
 sheet.save(OUT/'Valek_Reworked_Poses.jpg',quality=94)
 r.render('valek','idle',1.0,angle=20,zoom=.94).save(OUT/'Valek_Reworked_Model.png')
 # Orthogonal inspection angles are rendered from the same rig.
 angles=Image.new('RGB',(1980,900),(231,225,216));dd=ImageDraw.Draw(angles)
 for i,angle in enumerate([0,90,180]):
  angles.paste(r.render('valek','idle',1,angle=angle,zoom=.94),(i*660,50))
  dd.text((i*660+23,15),['FRONT','SIDE','BACK'][i],font=font(22,True),fill=(44,33,39))
 angles.save(ROOT/'renders/inspection_angles.jpg',quality=92)
 print('Stills rendered')

def video():
 r=rc.Renderer(860,860);W=H=1080;fps=24
 actor=r.actors['valek'];out=OUT/'Valek_Reworked_Preview.mp4'
 p=subprocess.Popen(['ffmpeg','-y','-v','error','-f','rawvideo','-pix_fmt','rgb24','-s',f'{W}x{H}','-r',str(fps),'-i','-','-an','-c:v','libx264','-preset','fast','-crf','19','-pix_fmt','yuv420p','-movflags','+faststart',str(out)],stdin=subprocess.PIPE)
 clips=[('model',6.0),('idle',8.0),('walk',3.9),('perform',7.2),('jumpscare',2.5)]
 for ci,(label,T) in enumerate(clips):
  frames=round(T*fps)
  for f in range(frames):
   t=f/fps
   angle=360*(t/T)+20 if label=='model' else 18 if label=='jumpscare' else 23
   view=r.render('valek','idle' if label=='model' else label,1 if label=='model' else t,angle=angle,zoom=.96)
   im=Image.new('RGB',(W,H),(230,224,215));im.paste(view,(110,124));d=ImageDraw.Draw(im)
   d.rectangle((0,0,W,117),fill=(27,23,30));d.text((46,22),'VALEK',font=font(45,True),fill=(240,231,218))
   d.text((49,80),'REWORKED  /  MINECRAFT BEDROCK',font=font(18),fill=(178,162,166))
   tags=['MODEL','IDLE','WALK','PERFORM','JUMPSCARE']
   for i,tag in enumerate(tags):
    x=34+i*204;col=(91,30,47) if i==ci else (115,105,108)
    d.rounded_rectangle((x,1010,x+196,1057),radius=5,fill=col)
    tw=d.textlength(tag,font=font(15,True));d.text((x+(196-tw)/2,1025),tag,font=font(15,True),fill=(244,238,228))
   d.rectangle((0,1073,int(W*(f+1)/frames),H),fill=(119,46,63))
   p.stdin.write(im.tobytes())
  print('Rendered',label,frames,flush=True)
 p.stdin.close();assert p.wait()==0;print(out,flush=True)

if __name__=='__main__':
 ap=argparse.ArgumentParser();ap.add_argument('--video',action='store_true');args=ap.parse_args()
 video() if args.video else stills()

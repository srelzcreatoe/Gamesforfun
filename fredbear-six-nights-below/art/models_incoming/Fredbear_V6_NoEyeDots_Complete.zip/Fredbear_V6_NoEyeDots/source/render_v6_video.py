"""Render V6's delivered model/keyframes to an H.264 review video.
Full-body orthographic view, perspective face view, forearm-relative hand details.
Requires numpy, Pillow, numba, and ffmpeg on PATH. No concept images are used.
"""
from __future__ import annotations
import json,math,subprocess,time,hashlib,sys
from pathlib import Path
import numpy as np
from PIL import Image,ImageDraw
import render_preview as r

ROOT=Path(__file__).resolve().parents[1];OUT=ROOT/'preview'
OUT.mkdir(exist_ok=True)
W,H,FPS=1440,900,30
REN=r.Renderer(684,714,1)
CLIPS={
 9:('SNAP BITE','Quick forward snap, recoil, then a controlled return.'),
 10:('DOUBLE LUNGE','Two forward beats with a delayed finger closure.'),
 11:('LEFT-HAND GRAB','The left free hand opens, reaches, closes, and draws back.'),
 7:('MICROPHONE SWAY','A looping stage rhythm with jaw and free-hand gestures.'),
 8:('CROWD POINT','An extended left-hand gesture with independent fingers.'),
 0:('V6 / ORIGINAL ANIMATIONS','Original V6 restored. Only the eye-dot cubes were removed.')}
HAND_MASKS={}
for side in ['l','r']:
    names={'hand_'+side}
    while True:
        extra=names|{b['name'] for b in r.B if b['parent'] in names}
        if extra==names:break
        names=extra
    HAND_MASKS[side]=np.isin(r.BONE,[r.BI[n] for n in names|{'forearm_'+side}])

# Perspective-correct depth, UV, and shadow interpolation, based on the same rasterizer.
import inspect
code=inspect.getsource(r.color_pass.py_func)
code=code.replace('def color_pass(', 'def color_pass_perspective(')
code=code.replace('zz=a*z0+b*z1+c*z2',
'''a=a/z0;b=b/z1;c=c/z2
                    inv=a+b+c
                    if inv<=0:continue
                    a/=inv;b/=inv;c/=inv
                    zz=1.0/inv''')
code=code.replace('@njit(cache=True)', '@njit(cache=False)')
exec(code, r.__dict__)

# Use fixed view bounds throughout all five clips so scale does not conceal motion.
def body(idx,t):
    return REN.frame(idx,t,yaw=-.20,pitch=.055,span=62,targetX=-1.6,targetY=25.0,
        title=False,shadowres=400)

def face(idx,t,w=706,h=338):
    m=r.matrices(idx,t);v,n=r.world_mesh(m)
    eye=np.array([0.,41.,-32.]);basis=r.view_basis(eye,[0.,41.,0.])
    q=(v-eye)@basis.T
    focus=h/(2*math.tan(math.radians(52)/2))
    vp=q.copy();vp[:,:,0]=w/2+q[:,:,0]*focus/q[:,:,2];vp[:,:,1]=h/2-q[:,:,1]*focus/q[:,:,2]
    res=400;lp=r.project(v,r.LIGHT_EYE,r.LB,res,res,92)
    sh=np.full((res,res),1e10);r.depth_pass(lp,sh)
    img=np.zeros((h,w,3),np.uint8);img[:]=[29,29,37]
    zb=np.full((h,w),1e10);ids=np.full((h,w),-1,np.int32)
    facing=(np.einsum('ij,ij->i',n,v.mean(axis=1)-eye)<-.001)&(q[:,:,2].min(axis=1)>.5)
    r.color_pass_perspective(vp[facing],n[facing],r.UV[facing],lp[facing],zb,sh,r.TEX,img,r.MAT[facing],r.CID[facing],ids)
    return Image.fromarray(img)

def hand(idx,t,side,w=344,h=295):
    m=r.matrices(idx,t);v,n=r.world_mesh(m);mask=HAND_MASKS[side]
    inv=np.linalg.inv(m[r.BI['forearm_'+side]])
    v=v[mask]@inv[:3,:3].T+inv[:3,3];n=n[mask]@inv[:3,:3].T
    wrist=(np.array(r.B[r.BI['hand_'+side]]['pivot'])-np.array(r.B[r.BI['forearm_'+side]]['pivot']))*r.S
    v-=wrist
    target=np.array([0.,-2.,0.]) if side=='l' else np.array([0.,-1.3,-.7])
    yaw=.5 if side=='l' else -.25;pitch=.08
    eye=target+np.array([90*math.sin(yaw)*math.cos(pitch),90*math.sin(pitch),-90*math.cos(yaw)*math.cos(pitch)])
    basis=r.view_basis(eye,target);span=7.8 if side=='l' else 9.8
    vp=r.project(v,eye,basis,w,h,span)
    le=np.array([-17.,24.,-25.]);lb=r.view_basis(le,[0,-1,0]);res=192
    lp=r.project(v,le,lb,res,res,25);sh=np.full((res,res),1e10);r.depth_pass(lp,sh)
    img=np.zeros((h,w,3),np.uint8);img[:]=[29,31,39]
    zb=np.full((h,w),1e10);ids=np.full((h,w),-1,np.int32);facing=n@basis[2]<-.001
    r.color_pass(vp[facing],n[facing],r.UV[mask][facing],lp[facing],zb,sh,r.TEX,img,r.MAT[mask][facing],r.CID[mask][facing],ids)
    return Image.fromarray(img)

def composite(idx,t,mode='NORMAL SPEED',progress=0):
    im=Image.new('RGB',(W,H),(19,21,28));d=ImageDraw.Draw(im)
    name,desc=CLIPS[idx]
    d.text((22,17),'FREDBEAR / V6',font=r.fnt(29,True),fill='#f4e9d8')
    d.text((23,55),name+'  |  '+mode,font=r.fnt(18,True),fill='#d6bc87')
    d.text((1420,22),'EYE DOTS REMOVED',anchor='ra',font=r.fnt(15),fill='#bcafca')
    d.text((1420,53),f'Clip time {t:.2f}s',anchor='ra',font=r.fnt(15),fill='#aaa6b2')
    d.line((20,88,1420,88),fill='#504357',width=1)
    d.text((24,104),'FULL MODEL  /  FIXED SCALE',font=r.fnt(15,True),fill='#c7bfcd')
    d.text((716,104),'FACE  /  FIXED PERSPECTIVE CAMERA',font=r.fnt(15,True),fill='#c7bfcd')
    im.paste(body(idx,t),(18,130));im.paste(face(idx,t),(716,130))
    d.rectangle((716,130,1422,468),outline='#4b4357')
    d.text((720,487),'HIS LEFT / FREE HAND',font=r.fnt(15,True),fill='#d9bc85')
    d.text((1078,487),'HIS RIGHT / MICROPHONE',font=r.fnt(15,True),fill='#d9bc85')
    im.paste(hand(idx,t,'l'),(716,514));im.paste(hand(idx,t,'r'),(1078,514))
    d.rectangle((716,514,1060,809),outline='#4b4357');d.rectangle((1078,514,1422,809),outline='#4b4357')
    d.text((720,824),'Hand close-ups use a fixed forearm frame.',font=r.fnt(14),fill='#aaa4b5')
    d.text((23,854),desc,font=r.fnt(16),fill='#e5d9c5')
    d.text((1420,856),'MODEL RENDER  |  NO AUDIO',anchor='ra',font=r.fnt(12),fill='#aaa4b5')
    d.rectangle((23,886,1420,889),fill='#403645');d.rectangle((23,886,23+round(1397*progress),889),fill='#bd9fd0')
    return im

def stills():
    tests=[('Snap_Peak',9,.44),('Lunge_Peak',10,.66),('Grab_Peak',11,.58),('Sway',7,.8),('Point',8,1.6)]
    for name,idx,t in tests:
        tic=time.time();composite(idx,t).save(OUT/f'Fredbear_V6_NoEyeDots_{name}.jpg',quality=93)
        print(name,round(time.time()-tic,2),flush=True)

def video():
    # Each scare at normal speed, followed by a clearly labelled half-speed replay.
    sections=[(0,1.0,0.,'OVERVIEW')]
    for idx in [9,10,11]:
        T=r.D['animations'][idx]['length']
        sections += [(idx,T+.18,1.,'NORMAL SPEED'),(idx,T*2+.18,.5,'HALF-SPEED REPLAY')]
    for idx in [7,8]:
        T=r.D['animations'][idx]['length']
        sections.append((idx,T+.4,1.,'LOOPING PERFORMANCE'))
    path=OUT/'Fredbear_V6_NoEyeDots_Preview.mp4'
    cmd=['ffmpeg','-hide_banner','-loglevel','error','-y','-f','rawvideo','-pix_fmt','rgb24','-s',f'{W}x{H}',
        '-r',str(FPS),'-i','-','-an','-c:v','libx264','-preset','veryfast','-crf','19','-pix_fmt','yuv420p',
        '-movflags','+faststart',str(path)]
    p=subprocess.Popen(cmd,stdin=subprocess.PIPE);count=0;total=sum(round(d*FPS) for _,d,_,_ in sections)
    manifest=[];tic=time.time()
    try:
        for idx,dur,speed,label in sections:
            frames=round(dur*FPS);T=r.D['animations'][idx]['length']
            manifest.append({'animation':r.D['animations'][idx]['name'],'playback_speed':speed,'label':label,
                'start_seconds':count/FPS,'duration_seconds':frames/FPS})
            for f in range(frames):
                t=f/FPS*speed
                if idx in [7,8]:t%=T
                else:t=min(t,T)
                im=composite(idx,t,label,count/max(1,total-1))
                p.stdin.write(im.tobytes());count+=1
            print(CLIPS[idx][0],label,f'{count}/{total} frames, {time.time()-tic:.1f}s',flush=True)
        p.stdin.close()
        if p.wait()!=0:raise RuntimeError('ffmpeg failed')
    except BaseException:
        p.kill();raise
    meta={'width':W,'height':H,'fps':FPS,'frames':count,'seconds':count/FPS,'audio':False,
        'model_sha256':hashlib.sha256((ROOT/'model/Fredbear_V6_NoEyeDots.bbmodel').read_bytes()).hexdigest(),
        'scene_sha256':hashlib.sha256((ROOT/'source/scene.json').read_bytes()).hexdigest(),
        'sections':manifest,'renderer':'CPU rasterizer; perspective-correct face panel, orthographic full-body panel; not an in-game recording.'}
    (OUT/'preview_manifest.json').write_text(json.dumps(meta,indent=2))
    print('Saved',path,flush=True)

if __name__=='__main__':
    if '--video' in sys.argv:video()
    else:stills()

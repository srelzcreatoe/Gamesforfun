"""Offscreen preview of the exact native Blockbench cubes and exported keyframes.
CPU depth-buffer rasterizer. Requires numpy, Pillow and numba; ffmpeg for video.
"""
from __future__ import annotations
import json,math,time
from pathlib import Path
import numpy as np
from PIL import Image,ImageDraw,ImageFont
from numba import njit

ROOT=Path(__file__).resolve().parents[1]
D=json.loads((ROOT/'source/scene.json').read_text()); B=D['bones'];BI={b['name']:i for i,b in enumerate(B)}
S=D['scale'];TEX=np.asarray(Image.open(ROOT/'texture/fredbear.png').convert('RGB')).copy()

def rotation(e):
    x,y,z=np.radians(e);sx,cx=np.sin(x),np.cos(x);sy,cy=np.sin(y),np.cos(y);sz,cz=np.sin(z),np.cos(z)
    return np.array([[cz*cy,cz*sy*sx-sz*cx,cz*sy*cx+sz*sx],[sz*cy,sz*sy*sx+cz*cx,sz*sy*cx-cz*sx],[-sy,cy*sx,cy*cx]])

def anim_tracks(a):
    tracks={}
    for b in a['animators'].values():
        channels={}
        for k in b['keyframes']:
            channels.setdefault(k['channel'],[]).append((k['time'],[float(k['data_points'][0][s]) for s in 'xyz']))
        tracks[b['name']]={ch:np.array(sorted(vals,key=lambda k:k[0]),dtype=object) for ch,vals in channels.items()}
    return tracks
TRACKS=[anim_tracks(a) for a in D['animations']]
def sample_track(keys,t):
    if keys is None:return np.zeros(3)
    if len(keys)==1:return np.array(keys[0,1],float)
    ts=keys[:,0].astype(float);idx=max(0,min(len(ts)-2,np.searchsorted(ts,t,side='right')-1));f=max(0,min(1,(t-ts[idx])/(ts[idx+1]-ts[idx])))
    a=np.array(keys[idx,1],float);v=np.array(keys[idx+1,1],float);return a+(v-a)*f

def matrices(idx,t):
    mats=[];tracks=TRACKS[idx]
    for b in B:
        p=np.array(b['pivot'])*S;parent=b['parent'];pp=np.array(B[BI[parent]]['pivot'])*S if parent else np.zeros(3)
        q=tracks.get(b['name'],{});r=np.array(b['rotation'])+sample_track(q.get('rotation'),t);pos=sample_track(q.get('position'),t)
        m=np.eye(4);m[:3,:3]=rotation(r);m[:3,3]=p-pp+pos
        if parent:m=mats[BI[parent]]@m
        mats.append(m)
    return np.array(mats)

VERT=[];NOR=[];UV=[];BONE=[];MAT=[];CID=[]
for ci,c in enumerate(D['cubes']):
    bi=BI[c['bone']];p=np.array(B[bi]['pivot']);o=(np.array(c['origin'])-p)*S;d=np.array(c['size'])*S
    x0,y0,z0=o;x1,y1,z1=o+d
    fs={
    'north':([[x1,y0,z0],[x0,y0,z0],[x0,y1,z0],[x1,y1,z0]],[0,0,-1]),
    'south':([[x0,y0,z1],[x1,y0,z1],[x1,y1,z1],[x0,y1,z1]],[0,0,1]),
    'east':([[x1,y0,z1],[x1,y0,z0],[x1,y1,z0],[x1,y1,z1]],[1,0,0]),
    'west':([[x0,y0,z0],[x0,y0,z1],[x0,y1,z1],[x0,y1,z0]],[-1,0,0]),
    'up':([[x0,y1,z1],[x1,y1,z1],[x1,y1,z0],[x0,y1,z0]],[0,1,0]),
    'down':([[x0,y0,z0],[x1,y0,z0],[x1,y0,z1],[x0,y0,z1]],[0,-1,0])}
    for f,(pts,norm) in fs.items():
        u,v,uu,vv=c['faces'][f]['uv'];uv=[[uu-.1,vv-.1],[u+.1,vv-.1],[u+.1,v+.1],[uu-.1,v+.1]]
        for tr in [[0,1,2],[0,2,3]]:
            VERT.append([pts[i] for i in tr]);NOR.append(norm);UV.append([uv[i] for i in tr]);BONE.append(bi);CID.append(ci)
            MAT.append(4 if c['material']=='white' else 3 if c['material']=='eye' else 2 if c['material'] in ['silver','metal','grille','purple','purple_dark','purple_light','black','nose'] else 0)
VERT=np.array(VERT,float);NOR=np.array(NOR,float);UV=np.array(UV,float);BONE=np.array(BONE,np.int32);MAT=np.array(MAT,np.int32);CID=np.array(CID,np.int32)

def normalize(a):return np.asarray(a)/np.linalg.norm(a)
def view_basis(eye,target):
    f=normalize(np.array(target)-eye);r=normalize(np.cross(f,[0,1,0]));u=np.cross(r,f);return np.array([r,u,f])
LIGHT_EYE=np.array([-47.,85.,-62.]);LB=view_basis(LIGHT_EYE,[0,22,0]);LIGHT_DIR=normalize([-0.6,1.,-.8]);FILL=normalize([.85,.30,.45])

def world_mesh(mats):
    r=mats[BONE,:3,:3];pos=mats[BONE,:3,3];verts=np.einsum('nij,nkj->nki',r,VERT)+pos[:,None,:];normals=np.einsum('nij,nj->ni',r,NOR)
    return verts,normals

def project(v,eye,basis,w,h,span):
    q=(v-eye)@basis.T;q[...,0]=w/2+q[...,0]*h/span;q[...,1]=h/2-q[...,1]*h/span;return q

@njit(cache=True)
def depth_pass(tris,zbuf):
    h,w=zbuf.shape
    for k in range(len(tris)):
        p=tris[k];x0,y0,z0=p[0];x1,y1,z1=p[1];x2,y2,z2=p[2]
        den=(y1-y2)*(x0-x2)+(x2-x1)*(y0-y2)
        if abs(den)<1e-8:continue
        xmin=max(0,int(math.floor(min(x0,x1,x2))));xmax=min(w-1,int(math.ceil(max(x0,x1,x2))))
        ymin=max(0,int(math.floor(min(y0,y1,y2))));ymax=min(h-1,int(math.ceil(max(y0,y1,y2))))
        for yy in range(ymin,ymax+1):
            for xx in range(xmin,xmax+1):
                a=((y1-y2)*(xx+.5-x2)+(x2-x1)*(yy+.5-y2))/den
                b=((y2-y0)*(xx+.5-x2)+(x0-x2)*(yy+.5-y2))/den;c=1-a-b
                if a>=-.0001 and b>=-.0001 and c>=-.0001:
                    zz=a*z0+b*z1+c*z2
                    if zz<zbuf[yy,xx]:zbuf[yy,xx]=zz

@njit(cache=True)
def shadow_factor(x,y,z,depth,bias=.105):
    h,w=depth.shape;xx=int(x);yy=int(y)
    if xx<1 or yy<1 or xx>=w-1 or yy>=h-1:return 1.
    v=0.
    for dy in (-1,0,1):
        for dx in (-1,0,1):v+=.26 if z-bias>depth[yy+dy,xx+dx] else 1.
    return v/9.

@njit(cache=True)
def draw_floor(img,zb,eye,basis,span,light_eye,lb,shadow,move):
    h,w=zb.shape;sc=span/h;ss=shadow.shape[0]/92
    for yy in range(h):
        for xx in range(w):
            px=(xx-w/2)*sc;py=-(yy-h/2)*sc
            origin=eye+basis[0]*px+basis[1]*py
            tt=(-.045-origin[1])/basis[2,1]
            if tt<=0:continue
            p=origin+basis[2]*tt
            dist=math.sqrt(p[0]*p[0]+p[2]*p[2]);fade=math.exp(-(dist/67)**2)
            ls=(p-light_eye)@lb.T
            sh=shadow_factor(shadow.shape[1]/2+ls[0]*ss,shadow.shape[0]/2-ls[1]*ss,ls[2],shadow,.16)
            line=(abs((p[0]/4+.5)%1-.5)<.012 or abs(((p[2]-move)/4+.5)%1-.5)<.012)
            c=(39.+(4 if line else 0))*sh
            for j in range(3):img[yy,xx,j]=(img[yy,xx,j]*(1-fade)+(c+(2 if j==2 else 0))*fade)
            zb[yy,xx]=tt

@njit(cache=True)
def color_pass(tris,normals,uv,lighttri,zbuf,shadow,texture,img,mats,cubeids,visibleids):
    h,w=zbuf.shape
    for k in range(len(tris)):
        p=tris[k];x0,y0,z0=p[0];x1,y1,z1=p[1];x2,y2,z2=p[2]
        den=(y1-y2)*(x0-x2)+(x2-x1)*(y0-y2)
        if abs(den)<1e-8:continue
        xmin=max(0,int(math.floor(min(x0,x1,x2))));xmax=min(w-1,int(math.ceil(max(x0,x1,x2))))
        ymin=max(0,int(math.floor(min(y0,y1,y2))));ymax=min(h-1,int(math.ceil(max(y0,y1,y2))))
        nn=normals[k];di=max(0.,nn[0]*-.424264+nn[1]*.707107+nn[2]*-.565685)
        fill=max(0.,nn[0]*.84370+nn[1]*.297776+nn[2]*.446663)
        hemi=.57+.10*(nn[1]*.5+.5)
        for yy in range(ymin,ymax+1):
            for xx in range(xmin,xmax+1):
                a=((y1-y2)*(xx+.5-x2)+(x2-x1)*(yy+.5-y2))/den
                b=((y2-y0)*(xx+.5-x2)+(x0-x2)*(yy+.5-y2))/den;c=1-a-b
                if a>=-.00001 and b>=-.00001 and c>=-.00001:
                    zz=a*z0+b*z1+c*z2
                    if zz>=zbuf[yy,xx]:continue
                    zbuf[yy,xx]=zz;visibleids[yy,xx]=cubeids[k]
                    u=int(a*uv[k,0,0]+b*uv[k,1,0]+c*uv[k,2,0]);v=int(a*uv[k,0,1]+b*uv[k,1,1]+c*uv[k,2,1]);u=max(0,min(255,u));v=max(0,min(255,v))
                    lp=a*lighttri[k,0]+b*lighttri[k,1]+c*lighttri[k,2]
                    sh=shadow_factor(lp[0],lp[1],lp[2],shadow,.36)
                    bright=hemi+di*.56*sh+fill*.15
                    if mats[k]==4:bright=.98
                    for j in range(3):img[yy,xx,j]=min(255,texture[v,u,j]*bright)

FONT='/usr/share/fonts/truetype/dejavu/DejaVuSans.ttf';BOLD='/usr/share/fonts/truetype/dejavu/DejaVuSans-Bold.ttf'
def fnt(sz,bold=False):return ImageFont.truetype(BOLD if bold else FONT,sz)

class Renderer:
    def __init__(self,w=880,h=1050,ss=1):self.w=w;self.h=h;self.ss=ss
    def frame(self,idx,t,yaw=-.32,pitch=.10,span=60,targetY=23.1,targetX=0,targetZ=0,title=True,label=None,caption=None,shadowres=768):
        w,h=int(self.w*self.ss),int(self.h*self.ss);dist=90
        eye=np.array([dist*math.sin(yaw)*math.cos(pitch),targetY+dist*math.sin(pitch),-dist*math.cos(yaw)*math.cos(pitch)])
        eye += np.array([targetX,0,targetZ])
        basis=view_basis(eye,[targetX,targetY,targetZ]);m=matrices(idx,t);v,n=world_mesh(m)
        lp=project(v,LIGHT_EYE,LB,shadowres,shadowres,92.)
        shadow=np.full((shadowres,shadowres),1e10,np.float64);depth_pass(lp,shadow)
        vp=project(v,eye,basis,w,h,span)
        # Remove back-facing faces before the color pass.
        facing=n@basis[2]<-.001
        bg=np.zeros((h,w,3),np.uint8);yy,xx=np.indices((h,w));rad=np.sqrt(((xx-w*.5)/w)**2+((yy-h*.4)/h)**2)
        for j,col in enumerate([27,26,34]):bg[:,:,j]=np.clip(col+9*(1-rad),0,255)
        zb=np.full((h,w),1e10,np.float64);ids=np.full((h,w),-1,np.int32)
        speed=8.13 if idx==1 else 19.68 if idx==2 else 0
        draw_floor(bg,zb,eye,basis,span,LIGHT_EYE,LB,shadow,speed*t)
        color_pass(vp[facing],n[facing],UV[facing],lp[facing],zb,shadow,TEX,bg,MAT[facing],CID[facing],ids)
        im=Image.fromarray(bg)
        if self.ss!=1:im=im.resize((self.w,self.h),Image.Resampling.LANCZOS)
        if title:
            dr=ImageDraw.Draw(im);w,h=im.size
            dr.text((26,23),'FREDBEAR / V6 ANIMATION MODEL',fill='#c7a779',font=fnt(10))
            dr.text((24,42),'FREDBEAR',fill='#f3ede5',font=fnt(29,True))
            dr.text((26,83),f'{len(D["cubes"])} rigid cubes  /  {len(B)} bones  /  {len(D["animations"])} clips',fill='#bab0b5',font=fnt(11))
            label=label or D['clips'][idx]['name'];dr.text((26,h-83),label,fill='#f3ece4',font=fnt(22,True))
            cap=caption or ('In-place cycle  /  Forward -Z' if idx in [1,2] else 'Articulated hands and fingers  /  Rigid joint animation')
            dr.text((27,h-47),cap,fill='#b6acb3',font=fnt(11))
            txt='ACTUAL MODEL RENDER';bb=dr.textbbox((0,0),txt,font=fnt(9));ww=bb[2]+18
            dr.rounded_rectangle((w-ww-25,h-80,w-25,h-55),radius=3,outline='#7b6040')
            dr.text((w-ww-16,h-73),txt,fill='#d7b67e',font=fnt(9))
        self.last_vertices=v;self.last_matrices=m;self.last_ids=ids
        return im

if __name__=='__main__':
    out=ROOT/'preview';out.mkdir(exist_ok=True)
    Renderer(900,1100,1.2).frame(0,0,yaw=-.2,pitch=.06,span=62,targetY=25,title=True).save(out/'Fredbear_V6_Overview.png')

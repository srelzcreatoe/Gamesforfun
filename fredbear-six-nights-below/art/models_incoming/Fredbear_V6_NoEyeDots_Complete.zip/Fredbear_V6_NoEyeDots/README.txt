FREDBEAR V6 - WHITE EYE DOTS REMOVED

BASE
This is the last delivered V6, restored before the V7 texture changes.

ONLY EDIT
Removed the four small eye-highlight cubes: one white glint and one small
catchlight per eye. The existing dark eye lenses and sockets remain.
No pixels in the original texture atlas were painted or recolored.
All remaining model elements, pivots, hand rig, proportions, materials and
all 12 embedded animation clips are unchanged from V6.

OPEN IN BLOCKBENCH
Open model/Fredbear_V6_NoEyeDots.bbmodel.
The original texture and all 12 animations are embedded.
The internal project name is still Fredbear_V6; that is intentional.
Use this model instead of V7. Do not apply V3/V4 wrist patches.

BEDROCK EXPORT
model/fredbear.geo.json contains the matching eye-dot-free geometry.
texture/fredbear.png is the original V6 texture, unchanged.
animations/fredbear.animation.json contains all 12 unchanged V6 clips.
The existing eye bones, identifiers and animation bindings are retained.

ALTERNATE ANIMATION EXPORTS
alternate_exports/individual/ contains each of the 12 unchanged clips.
alternate_exports/new_only/ contains just V6's five added clips.
Use either the combined export or the applicable alternate export route;
do not load duplicate animation identifiers together in a resource pack.

PREVIEW
preview/Fredbear_V6_NoEyeDots_Preview.mp4 is a new continuous model render.
It shows all three V6 jumpscares at normal speed and half speed, followed
by both added performance loops, with an initial idle overview.
The renderer uses the patched model geometry and the unchanged V6 keys.
The video is silent and is not an in-game recording.
The included stills are frames rendered from the same patched assets.
There are no painted eye overlays and no slideshow of old screenshots.

VALIDATION
See docs/Eye_Dot_Removal_Check.json for exact unchanged-content checks,
removed cube identifiers and hashes. The original texture bytes and all
animation-export bytes match V6. Every remaining model element and every
bone definition is equal to V6, and the rendering snapshot matches the
edited model and all embedded animation tracks.
Import/playback has not been tested interactively in Blockbench or Minecraft.
This is an asset package, not a spawnable add-on or a behavior pack.

RENDER SOURCE
Run python source/render_v6_video.py --video from a Python environment
with NumPy, Pillow, Numba, ffmpeg and suitable system fonts installed.
No font files are included.

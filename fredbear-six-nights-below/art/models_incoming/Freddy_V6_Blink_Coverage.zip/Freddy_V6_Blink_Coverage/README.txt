FREDDY V6: COMPLETE BLINK COVERAGE
=================================

OPEN freddy_v6.bbmodel.
This project embeds the matching texture and all six animation timelines.
The matching Bedrock geometry, combined animation JSON and individual clips
are included in the same folder.

IMPORTANT
Replace the model AND its animations together. The fix adds eyelid shutter
bones. Importing V6 animations into V5 geometry will not add these panels.
The geometry identifier is geometry.freddy.clean_voxel and the animation
identifiers remain animation.freddy.*.

WHAT WAS FIXED
V5 moved the short eyelid plate farther down, exposing the eyeball above it.
V6 retains that front plate and adds three overlapping rigid leaves behind
it on each eye. The upper leaf stays over the top of the eye; the other
leaves cover the space between that upper leaf and the moving lower edge.
There is no bone scaling or backwards lid rotation in this fix.

The downward overshoot from V5 was removed. Original V4 blink windows are
retained with a complete closure phase for each blink. The closed front
plate bottom is at 40.43 model units in head-local rest coordinates, below
the original eye bottom. Both dark and performance eyes are covered.

UNCHANGED
All 291 pre-existing cubes and their UVs, the texture, microphone, hands,
fingers and all non-eyelid animation channels are unchanged from V5.
White/blue eyes still appear in the two performance animations; idle,
walking, running and pose use the original dark-eye state.

PREVIEWS
freddy_v6_blink_closeup.mp4
  13.5 seconds. Idle and both performances, shown at 0.25x speed with
  front and two angled views. Each fully closed sample is briefly held
  for inspection and is labeled as a held frame.

freddy_v6_animation_preview.mp4
  Approximately 31 seconds. All six clips, with a live eye close-up.

freddy_v6_blink_comparison.png
  Open, closed and reopened dark-eye and performance-eye renders.

VALIDATION
The embedded and exported animation values match exactly. In 165 closed
blink raster tests, the eye meshes had zero visible pixels. These tests
cover every fully closed sampled blink keyframe, five horizontal camera
angles (-60, -30, 0, 30, 60 degrees) and three elevations (-25, 0, 25).
Full results and preservation checks are in validation_report.json.

These are custom-rendered previews of the actual asset data, not generated
concept images. Native Blockbench and Minecraft execution was not tested.
This is a model/animation asset package, not a complete spawnable add-on.

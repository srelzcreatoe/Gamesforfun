scriptevent gs:control preview

scriptevent gs:control enable

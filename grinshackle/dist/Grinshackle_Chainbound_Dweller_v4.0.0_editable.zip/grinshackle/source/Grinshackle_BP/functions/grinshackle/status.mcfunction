scriptevent gs:control status

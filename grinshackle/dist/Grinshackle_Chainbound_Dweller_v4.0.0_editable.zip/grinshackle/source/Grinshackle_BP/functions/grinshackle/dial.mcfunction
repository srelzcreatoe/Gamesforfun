scriptevent gs:control dial

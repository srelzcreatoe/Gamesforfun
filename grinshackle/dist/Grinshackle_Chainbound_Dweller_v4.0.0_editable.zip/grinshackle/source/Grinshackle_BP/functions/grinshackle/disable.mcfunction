scriptevent gs:control disable

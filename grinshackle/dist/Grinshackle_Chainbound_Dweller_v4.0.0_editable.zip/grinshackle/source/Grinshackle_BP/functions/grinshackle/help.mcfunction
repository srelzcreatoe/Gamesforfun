scriptevent gs:control help

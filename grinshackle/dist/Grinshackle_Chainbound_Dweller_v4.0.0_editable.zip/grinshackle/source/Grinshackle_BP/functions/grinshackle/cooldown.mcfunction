scriptevent gs:control cooldown

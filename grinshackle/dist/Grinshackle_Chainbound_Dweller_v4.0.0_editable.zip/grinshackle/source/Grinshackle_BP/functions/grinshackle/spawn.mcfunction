scriptevent gs:control spawn

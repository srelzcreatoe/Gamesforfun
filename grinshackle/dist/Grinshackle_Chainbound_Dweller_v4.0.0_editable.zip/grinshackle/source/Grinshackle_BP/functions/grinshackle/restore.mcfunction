scriptevent gs:control restore

scriptevent gs:control end

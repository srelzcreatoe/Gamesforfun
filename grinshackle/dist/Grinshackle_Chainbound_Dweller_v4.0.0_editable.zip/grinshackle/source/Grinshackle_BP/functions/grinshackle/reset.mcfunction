scriptevent gs:control reset

scriptevent gs:control mute

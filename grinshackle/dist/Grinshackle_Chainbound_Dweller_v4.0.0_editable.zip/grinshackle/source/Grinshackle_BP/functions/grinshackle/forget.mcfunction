scriptevent gs:control forget

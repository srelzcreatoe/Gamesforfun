scriptevent gs:control admin
